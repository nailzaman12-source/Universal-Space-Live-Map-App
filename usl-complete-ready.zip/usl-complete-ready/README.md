# 🌌 UNIVERSAL SPACE LIVE

**Explore Earth. Discover Space. Learn with AI.**

---

## 🚀 DEPLOY IN 3 COMMANDS!

```bash
# 1. Install
npm install

# 2. Install Vercel
npm install -g vercel

# 3. Deploy
vercel
```

**Done! 🎉**

---

## 📱 Features

✅ Beautiful landing page
✅ User authentication
✅ Real-time dashboard
✅ Achievement system
✅ Responsive design
✅ Mobile friendly

---

## 🎯 Live URL

After deployment:
```
https://your-app.vercel.app
```

---

## 📝 Full Guide

See: QUICK-DEPLOY.md

---

**Made with ❤️ for space education**

