/**
 * Disaster Tracking Routes
 * Real-time natural disasters monitoring
 */

const express = require('express');
const router = express.Router();
const axios = require('axios');

// @route   GET /api/disaster/earthquakes
// @desc    Get recent earthquakes worldwide
// @access  Public
router.get('/earthquakes', async (req, res) => {
  try {
    const minMagnitude = req.query.minMagnitude || 2.5;
    const response = await axios.get(
      `https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson`
    );

    const earthquakes = response.data.features
      .filter(f => f.properties.mag >= minMagnitude)
      .map(feature => ({
        id: feature.id,
        magnitude: feature.properties.mag,
        place: feature.properties.place,
        time: new Date(feature.properties.time),
        depth: feature.geometry.coordinates[2],
        coordinates: {
          latitude: feature.geometry.coordinates[1],
          longitude: feature.geometry.coordinates[0]
        },
        felt: feature.properties.felt,
        tsunami: feature.properties.tsunami,
        url: feature.properties.url
      }))
      .sort((a, b) => b.magnitude - a.magnitude);

    res.json({
      source: 'USGS Earthquake Hazards Program',
      minMagnitude: minMagnitude,
      count: earthquakes.length,
      earthquakes: earthquakes
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch earthquake data',
      message: error.message
    });
  }
});

// @route   GET /api/disaster/volcanoes
// @desc    Get volcanic activity information
// @access  Public
router.get('/volcanoes', async (req, res) => {
  try {
    // This would integrate with a volcano API or database
    res.json({
      message: 'Volcano data endpoint',
      note: 'Integrate with volcano monitoring service',
      available_data: [
        'Active volcanoes',
        'Recent eruptions',
        'Ash clouds',
        'Alert levels'
      ]
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch volcano data',
      message: error.message
    });
  }
});

// @route   GET /api/disaster/hurricanes
// @desc    Get hurricane tracking data
// @access  Public
router.get('/hurricanes', async (req, res) => {
  try {
    // This would integrate with NOAA hurricane tracking
    res.json({
      message: 'Hurricane tracking endpoint',
      note: 'Integrate with NOAA data',
      available_data: [
        'Active hurricanes',
        'Wind speed',
        'Track predictions',
        'Alert levels'
      ]
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch hurricane data',
      message: error.message
    });
  }
});

// @route   GET /api/disaster/floods
// @desc    Get flood warning data
// @access  Public
router.get('/floods', async (req, res) => {
  try {
    res.json({
      message: 'Flood warning endpoint',
      note: 'Integrate with hydrological services',
      available_data: [
        'Flood warnings',
        'River levels',
        'Precipitation forecast',
        'Risk areas'
      ]
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch flood data',
      message: error.message
    });
  }
});

// @route   GET /api/disaster/wildfires
// @desc    Get wildfire tracking data
// @access  Public
router.get('/wildfires', async (req, res) => {
  try {
    // This would integrate with NASA FIRMS or similar service
    res.json({
      message: 'Wildfire tracking endpoint',
      note: 'Integrate with NASA FIRMS or similar',
      available_data: [
        'Active fires',
        'Fire size',
        'Coordinates',
        'Risk areas'
      ]
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch wildfire data',
      message: error.message
    });
  }
});

// @route   GET /api/disaster/alerts/:region
// @desc    Get disaster alerts for a region
// @access  Public
router.get('/alerts/:region', async (req, res) => {
  try {
    const { region } = req.params;

    res.json({
      region: region,
      alerts: [],
      lastUpdated: new Date(),
      sources: [
        'USGS Earthquakes',
        'NOAA Weather Alerts',
        'NASA Fire Alerts',
        'Volcano Monitoring'
      ]
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch alerts',
      message: error.message
    });
  }
});

// @route   GET /api/disaster/stats
// @desc    Get disaster statistics
// @access  Public
router.get('/stats', async (req, res) => {
  try {
    res.json({
      message: '🌍 Disaster Tracking Statistics',
      available_endpoints: [
        '/api/disaster/earthquakes - Earthquake data',
        '/api/disaster/volcanoes - Volcanic activity',
        '/api/disaster/hurricanes - Hurricane tracking',
        '/api/disaster/floods - Flood warnings',
        '/api/disaster/wildfires - Active fires',
        '/api/disaster/alerts/:region - Regional alerts'
      ],
      data_sources: [
        'USGS Earthquake Hazards Program',
        'NOAA',
        'NASA FIRMS',
        'Volcano Monitoring Networks'
      ],
      update_frequency: 'Real-time to hourly'
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch statistics',
      message: error.message
    });
  }
});

module.exports = router;
