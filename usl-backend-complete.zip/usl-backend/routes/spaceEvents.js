/**
 * Space Events Routes
 * Track space phenomena - satellites, ISS, solar events, etc.
 */

const express = require('express');
const router = express.Router();
const axios = require('axios');

// @route   GET /api/space-events/iss-location
// @desc    Get current ISS location
// @access  Public
router.get('/iss-location', async (req, res) => {
  try {
    const response = await axios.get('https://api.wheretheiss.at/v1/satellites/25544');

    res.json({
      satellite: 'International Space Station',
      latitude: response.data.latitude,
      longitude: response.data.longitude,
      altitude: response.data.altitude,
      velocity: response.data.velocity,
      visibility: response.data.visibility,
      timestamp: new Date(response.data.timestamp * 1000)
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch ISS location',
      message: error.message
    });
  }
});

// @route   GET /api/space-events/satellite/:noradId
// @desc    Get satellite position
// @access  Public
router.get('/satellite/:noradId', async (req, res) => {
  try {
    const { noradId } = req.params;
    const response = await axios.get(
      `https://api.wheretheiss.at/v1/satellites/${noradId}`
    );

    res.json({
      noradId: noradId,
      latitude: response.data.latitude,
      longitude: response.data.longitude,
      altitude: response.data.altitude,
      velocity: response.data.velocity,
      timestamp: new Date(response.data.timestamp * 1000)
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch satellite data',
      message: error.message
    });
  }
});

// @route   GET /api/space-events/meteor-showers
// @desc    Get upcoming meteor showers
// @access  Public
router.get('/meteor-showers', async (req, res) => {
  try {
    const meteorShowers = [
      {
        name: 'Quadrantids',
        peak: '2024-01-03 to 2024-01-04',
        rate: '40 per hour',
        radiant: 'Boötes'
      },
      {
        name: 'Lyrids',
        peak: '2024-04-22 to 2024-04-23',
        rate: '20 per hour',
        radiant: 'Lyra'
      },
      {
        name: 'Perseids',
        peak: '2024-08-11 to 2024-08-12',
        rate: '60 per hour',
        radiant: 'Perseus'
      },
      {
        name: 'Geminids',
        peak: '2024-12-13 to 2024-12-14',
        rate: '75 per hour',
        radiant: 'Gemini'
      }
    ];

    res.json({
      source: 'Meteor Shower Calendar',
      showers: meteorShowers,
      note: 'Best viewing: after midnight, away from light pollution'
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch meteor shower data',
      message: error.message
    });
  }
});

// @route   GET /api/space-events/space-launches
// @desc    Get upcoming space launches
// @access  Public
router.get('/space-launches', async (req, res) => {
  try {
    // This would integrate with Launch Library API or similar
    const launches = [
      {
        mission: 'Sample Mission 1',
        rocket: 'Falcon 9',
        launchSite: 'Kennedy Space Center',
        window: '2024-02-15',
        status: 'Planned'
      },
      {
        mission: 'Sample Mission 2',
        rocket: 'Falcon Heavy',
        launchSite: 'Cape Canaveral',
        window: '2024-03-20',
        status: 'Planned'
      }
    ];

    res.json({
      source: 'Space Launch Schedule',
      launches: launches,
      note: 'Integrate with Launch Library API for real data'
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch launch data',
      message: error.message
    });
  }
});

// @route   GET /api/space-events/sun-moon
// @desc    Get sun and moon rise/set times
// @access  Public
router.get('/sun-moon', async (req, res) => {
  try {
    const { lat = 0, lon = 0 } = req.query;

    // Calculate approximate times (would use proper astronomy library)
    const today = new Date();
    const sunrise = new Date(today.getTime() + 6 * 3600000);
    const sunset = new Date(today.getTime() + 18 * 3600000);
    const moonrise = new Date(today.getTime() + 8 * 3600000);
    const moonset = new Date(today.getTime() + 20 * 3600000);

    res.json({
      location: { latitude: lat, longitude: lon },
      date: today.toISOString().split('T')[0],
      sun: {
        sunrise: sunrise,
        sunset: sunset,
        noon: new Date(today.getTime() + 12 * 3600000)
      },
      moon: {
        rise: moonrise,
        set: moonset,
        illumination: 50
      }
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch celestial data',
      message: error.message
    });
  }
});

// @route   GET /api/space-events/lunar-calendar
// @desc    Get lunar phases calendar
// @access  Public
router.get('/lunar-calendar', async (req, res) => {
  try {
    const phases = [
      { phase: 'New Moon', date: '2024-01-11', illumination: 0 },
      { phase: 'First Quarter', date: '2024-01-18', illumination: 50 },
      { phase: 'Full Moon', date: '2024-01-25', illumination: 100 },
      { phase: 'Last Quarter', date: '2024-02-02', illumination: 50 }
    ];

    res.json({
      source: 'Lunar Phase Calendar',
      phases: phases,
      note: 'Dates are approximate'
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch lunar calendar',
      message: error.message
    });
  }
});

// @route   GET /api/space-events/stats
// @desc    Get space events statistics
// @access  Public
router.get('/stats', async (req, res) => {
  res.json({
    message: '🚀 Space Events Tracking',
    available_endpoints: [
      '/api/space-events/iss-location - ISS real-time position',
      '/api/space-events/satellite/:noradId - Satellite tracking',
      '/api/space-events/meteor-showers - Meteor shower calendar',
      '/api/space-events/space-launches - Upcoming launches',
      '/api/space-events/sun-moon - Sun and moon times',
      '/api/space-events/lunar-calendar - Lunar phases'
    ],
    data_sources: [
      'NASA ISS Tracker',
      'Celestrak Satellite Database',
      'Space Launch Schedule',
      'Astronomical Calculations'
    ]
  });
});

module.exports = router;
