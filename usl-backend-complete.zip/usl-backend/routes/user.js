/**
 * User Routes
 * User profile, progress tracking, and achievements
 */

const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { authMiddleware } = require('../middleware/auth');

// @route   GET /api/user/profile
// @desc    Get user profile
// @access  Private
router.get('/profile', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('-password');
    res.json({ user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// @route   PUT /api/user/profile
// @desc    Update user profile
// @access  Private
router.put('/profile', authMiddleware, async (req, res) => {
  try {
    const { name, bio, interests, avatar } = req.body;
    const user = await User.findById(req.userId);

    if (name) user.name = name;
    if (bio) user.bio = bio;
    if (interests) user.interests = interests;
    if (avatar) user.avatar = avatar;

    await user.save();

    res.json({
      message: 'Profile updated',
      user
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// @route   GET /api/user/progress
// @desc    Get user learning progress
// @access  Private
router.get('/progress', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    res.json({
      totalLessonsCompleted: user.totalLessonsCompleted,
      totalQuizzesCompleted: user.totalQuizzesCompleted,
      achievements: user.achievements,
      level: user.level,
      experiencePoints: user.experiencePoints,
      learningStreak: user.learningStreak
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// @route   GET /api/user/achievements
// @desc    Get user achievements
// @access  Private
router.get('/achievements', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    res.json({
      achievements: user.achievements,
      totalAchievements: user.achievements.length,
      badges: user.achievements.filter(a => a.type === 'badge')
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// @route   POST /api/user/lesson-complete/:lessonId
// @desc    Mark lesson as complete
// @access  Private
router.post('/lesson-complete/:lessonId', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    user.totalLessonsCompleted += 1;
    user.experiencePoints += 10;
    user.learningStreak += 1;

    await user.save();

    res.json({
      message: 'Lesson completed',
      progress: {
        totalLessons: user.totalLessonsCompleted,
        xp: user.experiencePoints
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// @route   GET /api/user/leaderboard
// @desc    Get leaderboard by experience points
// @access  Public
router.get('/leaderboard', async (req, res) => {
  try {
    const topUsers = await User.find()
      .select('name experiencePoints level avatar')
      .sort({ experiencePoints: -1 })
      .limit(10);

    const leaderboard = topUsers.map((user, index) => ({
      rank: index + 1,
      name: user.name,
      experiencePoints: user.experiencePoints,
      level: user.level,
      avatar: user.avatar
    }));

    res.json({ leaderboard });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
