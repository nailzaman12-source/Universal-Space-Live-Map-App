/**
 * NASA API Routes
 * APOD, Earthquakes, Solar Events, Asteroids
 */

const express = require('express');
const router = express.Router();
const axios = require('axios');

const NASA_API_KEY = process.env.NASA_API_KEY || 'DEMO_KEY';
const NASA_BASE_URL = 'https://api.nasa.gov';

// @route   GET /api/nasa/apod
// @desc    Get NASA Astronomy Picture of the Day
// @access  Public
router.get('/apod', async (req, res) => {
  try {
    const response = await axios.get(`${NASA_BASE_URL}/planetary/apod`, {
      params: {
        api_key: NASA_API_KEY,
        count: req.query.count || 1
      }
    });

    res.json({
      source: 'NASA APOD',
      data: response.data
    });
  } catch (error) {
    console.error('APOD Error:', error.message);
    res.status(500).json({
      error: 'Failed to fetch APOD data',
      message: error.message
    });
  }
});

// @route   GET /api/nasa/apod/:date
// @desc    Get APOD for specific date (YYYY-MM-DD)
// @access  Public
router.get('/apod/:date', async (req, res) => {
  try {
    const { date } = req.params;
    
    // Validate date format
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({
        error: 'Invalid date format. Use YYYY-MM-DD'
      });
    }

    const response = await axios.get(`${NASA_BASE_URL}/planetary/apod`, {
      params: {
        api_key: NASA_API_KEY,
        date: date
      }
    });

    res.json({
      source: 'NASA APOD',
      date: date,
      data: response.data
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch APOD data',
      message: error.message
    });
  }
});

// @route   GET /api/nasa/earthquakes
// @desc    Get recent earthquakes data (via USGS)
// @access  Public
router.get('/earthquakes', async (req, res) => {
  try {
    const response = await axios.get('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson');

    const earthquakes = response.data.features.map(feature => ({
      magnitude: feature.properties.mag,
      place: feature.properties.place,
      time: new Date(feature.properties.time),
      depth: feature.geometry.coordinates[2],
      coordinates: {
        latitude: feature.geometry.coordinates[1],
        longitude: feature.geometry.coordinates[0]
      },
      url: feature.properties.url
    }));

    res.json({
      source: 'USGS Earthquake Hazards Program',
      count: earthquakes.length,
      data: earthquakes
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch earthquake data',
      message: error.message
    });
  }
});

// @route   GET /api/nasa/solar-events
// @desc    Get solar activity data
// @access  Public
router.get('/solar-events', async (req, res) => {
  try {
    const response = await axios.get(`${NASA_BASE_URL}/DONKI/events`, {
      params: {
        api_key: NASA_API_KEY,
        startDate: req.query.startDate || '2024-01-01',
        endDate: req.query.endDate || new Date().toISOString().split('T')[0]
      }
    });

    res.json({
      source: 'NASA DONKI (Space Weather Database)',
      data: response.data
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch solar events',
      message: error.message
    });
  }
});

// @route   GET /api/nasa/asteroids
// @desc    Get near-Earth asteroids data
// @access  Public
router.get('/asteroids', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

    const response = await axios.get(`${NASA_BASE_URL}/neo/rest/v1/feed`, {
      params: {
        api_key: NASA_API_KEY,
        start_date: today,
        end_date: tomorrow
      }
    });

    const asteroids = response.data.near_earth_objects[today]?.map(asteroid => ({
      name: asteroid.name,
      diameter: asteroid.estimated_diameter.kilometers.estimated_diameter_max,
      closeApproachDate: asteroid.close_approach_data[0]?.close_approach_date,
      missDistance: asteroid.close_approach_data[0]?.miss_distance?.kilometers,
      url: asteroid.nasa_jpl_url,
      isPotentiallyHazardous: asteroid.is_potentially_hazardous_asteroid
    })) || [];

    res.json({
      source: 'NASA NEO (Near Earth Objects)',
      date: today,
      count: asteroids.length,
      data: asteroids
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch asteroid data',
      message: error.message
    });
  }
});

// @route   GET /api/nasa/mars-rover
// @desc    Get Mars Rover images
// @access  Public
router.get('/mars-rover', async (req, res) => {
  try {
    const sol = req.query.sol || 1000;
    const rover = req.query.rover || 'curiosity';

    const response = await axios.get(
      `${NASA_BASE_URL}/mars-photos/api/v1/rovers/${rover}/photos`,
      {
        params: {
          api_key: NASA_API_KEY,
          sol: sol,
          page: 1
        }
      }
    );

    res.json({
      source: 'NASA Mars Rover Photos',
      rover: rover,
      sol: sol,
      count: response.data.photos.length,
      photos: response.data.photos.slice(0, 10) // Limit to 10
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch Mars Rover data',
      message: error.message
    });
  }
});

// @route   GET /api/nasa/earth-imagery
// @desc    Get satellite imagery of Earth
// @access  Public
router.get('/earth-imagery', async (req, res) => {
  try {
    const { lat, lon, dim = 0.15, date } = req.query;

    if (!lat || !lon) {
      return res.status(400).json({
        error: 'Missing required parameters',
        required: ['lat', 'lon'],
        optional: ['dim', 'date']
      });
    }

    const imageUrl = `${NASA_BASE_URL}/planetary/earth/imagery`;
    const response = await axios.get(imageUrl, {
      params: {
        api_key: NASA_API_KEY,
        lon: lon,
        lat: lat,
        dim: dim,
        date: date || undefined
      }
    });

    res.json({
      source: 'NASA Earth Imagery',
      coordinates: { latitude: lat, longitude: lon },
      imageUrl: response.config.url,
      dimension: dim
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch Earth imagery',
      message: error.message
    });
  }
});

// @route   GET /api/nasa/stats
// @desc    Get API statistics
// @access  Public
router.get('/stats', async (req, res) => {
  res.json({
    message: '🌌 NASA API Integration Statistics',
    available_endpoints: [
      '/api/nasa/apod - Astronomy Picture of the Day',
      '/api/nasa/apod/:date - APOD for specific date',
      '/api/nasa/earthquakes - Real-time earthquake data',
      '/api/nasa/solar-events - Solar activity tracking',
      '/api/nasa/asteroids - Near-Earth asteroid data',
      '/api/nasa/mars-rover - Mars Rover images',
      '/api/nasa/earth-imagery - Satellite Earth images'
    ],
    powered_by: [
      'NASA APOD',
      'USGS Earthquake Hazards',
      'NASA DONKI',
      'NASA NEO',
      'NASA Mars Rover Photos',
      'NASA Earth Imagery'
    ]
  });
});

module.exports = router;
