/**
 * Weather API Routes
 * Real-time weather data and forecasts
 */

const express = require('express');
const router = express.Router();
const axios = require('axios');

const WEATHER_API_KEY = process.env.OPENWEATHER_API_KEY || 'DEMO_KEY';
const WEATHER_BASE_URL = 'https://api.openweathermap.org/data';

// @route   GET /api/weather/current/:city
// @desc    Get current weather for a city
// @access  Public
router.get('/current/:city', async (req, res) => {
  try {
    const { city } = req.params;

    const response = await axios.get(`${WEATHER_BASE_URL}/2.5/weather`, {
      params: {
        q: city,
        appid: WEATHER_API_KEY,
        units: 'metric'
      }
    });

    const data = response.data;

    res.json({
      city: data.name,
      country: data.sys.country,
      coordinates: {
        latitude: data.coord.lat,
        longitude: data.coord.lon
      },
      weather: {
        main: data.weather[0].main,
        description: data.weather[0].description,
        icon: data.weather[0].icon
      },
      temperature: {
        current: data.main.temp,
        feels_like: data.main.feels_like,
        min: data.main.temp_min,
        max: data.main.temp_max
      },
      pressure: data.main.pressure,
      humidity: data.main.humidity,
      visibility: data.visibility,
      windSpeed: data.wind.speed,
      cloudiness: data.clouds.all,
      timestamp: new Date(data.dt * 1000)
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch weather data',
      message: error.message
    });
  }
});

// @route   GET /api/weather/forecast/:city
// @desc    Get 5-day weather forecast
// @access  Public
router.get('/forecast/:city', async (req, res) => {
  try {
    const { city } = req.params;

    const response = await axios.get(`${WEATHER_BASE_URL}/2.5/forecast`, {
      params: {
        q: city,
        appid: WEATHER_API_KEY,
        units: 'metric'
      }
    });

    const forecasts = response.data.list.map(item => ({
      timestamp: new Date(item.dt * 1000),
      temperature: item.main.temp,
      weather: item.weather[0].main,
      description: item.weather[0].description,
      humidity: item.main.humidity,
      windSpeed: item.wind.speed,
      precipitation: item.rain?.['3h'] || 0
    }));

    res.json({
      city: response.data.city.name,
      country: response.data.city.country,
      forecast: forecasts
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch forecast data',
      message: error.message
    });
  }
});

// @route   GET /api/weather/coordinates/:lat/:lon
// @desc    Get weather by coordinates
// @access  Public
router.get('/coordinates/:lat/:lon', async (req, res) => {
  try {
    const { lat, lon } = req.params;

    const response = await axios.get(`${WEATHER_BASE_URL}/2.5/weather`, {
      params: {
        lat: lat,
        lon: lon,
        appid: WEATHER_API_KEY,
        units: 'metric'
      }
    });

    const data = response.data;

    res.json({
      coordinates: {
        latitude: lat,
        longitude: lon
      },
      location: data.name,
      weather: {
        main: data.weather[0].main,
        description: data.weather[0].description
      },
      temperature: data.main.temp,
      humidity: data.main.humidity,
      windSpeed: data.wind.speed
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch weather data',
      message: error.message
    });
  }
});

// @route   GET /api/weather/uv/:lat/:lon
// @desc    Get UV index
// @access  Public
router.get('/uv/:lat/:lon', async (req, res) => {
  try {
    const { lat, lon } = req.params;

    const response = await axios.get(`${WEATHER_BASE_URL}/2.5/uvi`, {
      params: {
        lat: lat,
        lon: lon,
        appid: WEATHER_API_KEY
      }
    });

    res.json({
      coordinates: { latitude: lat, longitude: lon },
      uvIndex: response.data.value,
      timestamp: new Date(response.data.date * 1000),
      riskLevel: getRiskLevel(response.data.value)
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch UV data',
      message: error.message
    });
  }
});

// Helper function to determine UV risk level
function getRiskLevel(uv) {
  if (uv < 3) return 'Low';
  if (uv < 6) return 'Moderate';
  if (uv < 8) return 'High';
  if (uv < 11) return 'Very High';
  return 'Extreme';
}

module.exports = router;
