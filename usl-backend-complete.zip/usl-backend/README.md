# 🌌 Universal Space Live - Backend API

Complete Node.js/Express backend for the Universal Space Live educational platform. Integrates with NASA APIs, weather data, disaster tracking, and space events.

## 🎯 Features

✅ **NASA API Integration** - APOD, Earthquakes, Solar Events, Asteroids, Mars Rover, Earth Imagery
✅ **Real-time Weather Data** - Current weather, forecasts, UV index
✅ **Disaster Tracking** - Earthquakes, hurricanes, floods, wildfires
✅ **Space Events** - ISS tracking, satellite tracking, meteor showers, space launches
✅ **User Authentication** - JWT-based login/signup
✅ **User Progress Tracking** - Lessons, quizzes, achievements, experience points
✅ **Leaderboard System** - Top earners by experience points
✅ **Production Ready** - Security headers, CORS, compression, error handling

## 🛠️ Tech Stack

- **Runtime:** Node.js 14+
- **Framework:** Express.js 4.x
- **Database:** MongoDB
- **Authentication:** JWT (JSON Web Tokens)
- **Encryption:** bcryptjs
- **External APIs:** NASA, OpenWeatherMap, USGS, etc.

## 📋 Prerequisites

- Node.js >= 14
- npm >= 6
- MongoDB (local or MongoDB Atlas)
- API Keys:
  - NASA API: https://api.nasa.gov
  - OpenWeather API: https://openweathermap.org/api
  - Others are free/public

## 🚀 Quick Start

### 1. Installation

```bash
# Extract files
cd universal-space-live-backend

# Install dependencies
npm install
```

### 2. Environment Setup

```bash
# Copy environment template
cp .env.example .env

# Edit .env and add your API keys
nano .env
```

### 3. Start Server

**Development:**
```bash
npm run dev
```

**Production:**
```bash
npm start
```

Server runs at: `http://localhost:5000`

### 4. Test API

```bash
# Health check
curl http://localhost:5000/api/health

# Get NASA APOD
curl http://localhost:5000/api/nasa/apod

# Get earthquakes
curl http://localhost:5000/api/disaster/earthquakes
```

## 📁 Project Structure

```
usl-backend/
├── config/
│   └── db.js                 # Database configuration
├── middleware/
│   └── auth.js              # JWT authentication
├── models/
│   └── User.js              # User schema
├── routes/
│   ├── auth.js              # Authentication endpoints
│   ├── nasa.js              # NASA API integration
│   ├── weather.js           # Weather data
│   ├── disaster.js          # Disaster tracking
│   ├── spaceEvents.js       # Space events tracking
│   └── user.js              # User profile & progress
├── server.js                # Main application
├── package.json             # Dependencies
├── .env.example             # Environment template
├── .gitignore              # Git ignore config
└── README.md               # This file
```

## 🔌 API Endpoints

### Authentication

```
POST   /api/auth/signup          - Register new user
POST   /api/auth/login           - User login
GET    /api/auth/me              - Get current user
```

### NASA APIs

```
GET    /api/nasa/apod                    - Astronomy Picture of the Day
GET    /api/nasa/apod/:date              - APOD for specific date (YYYY-MM-DD)
GET    /api/nasa/earthquakes             - Recent earthquakes worldwide
GET    /api/nasa/solar-events            - Solar activity data
GET    /api/nasa/asteroids               - Near-Earth asteroids
GET    /api/nasa/mars-rover              - Mars Rover images
GET    /api/nasa/earth-imagery           - Satellite Earth imagery
GET    /api/nasa/stats                   - API statistics
```

### Weather

```
GET    /api/weather/current/:city        - Current weather for city
GET    /api/weather/forecast/:city       - 5-day forecast
GET    /api/weather/coordinates/:lat/:lon - Weather by coordinates
GET    /api/weather/uv/:lat/:lon         - UV index
```

### Disaster Tracking

```
GET    /api/disaster/earthquakes         - Earthquake data
GET    /api/disaster/volcanoes           - Volcanic activity
GET    /api/disaster/hurricanes          - Hurricane tracking
GET    /api/disaster/floods              - Flood warnings
GET    /api/disaster/wildfires           - Active fires
GET    /api/disaster/alerts/:region      - Regional alerts
GET    /api/disaster/stats               - Statistics
```

### Space Events

```
GET    /api/space-events/iss-location    - ISS real-time position
GET    /api/space-events/satellite/:noradId - Satellite tracking
GET    /api/space-events/meteor-showers  - Meteor shower calendar
GET    /api/space-events/space-launches  - Upcoming launches
GET    /api/space-events/sun-moon        - Sun/moon rise/set times
GET    /api/space-events/lunar-calendar  - Lunar phases
GET    /api/space-events/stats           - Statistics
```

### User Profile

```
GET    /api/user/profile                 - Get user profile
PUT    /api/user/profile                 - Update profile
GET    /api/user/progress                - Learning progress
GET    /api/user/achievements            - User achievements
POST   /api/user/lesson-complete/:id     - Mark lesson complete
GET    /api/user/leaderboard             - Top users leaderboard
```

## 💾 Database Schema

### User Model

```javascript
{
  name: String,
  email: String (unique),
  password: String (hashed),
  avatar: String,
  bio: String,
  interests: [String],
  level: Number,
  experiencePoints: Number,
  totalLessonsCompleted: Number,
  totalQuizzesCompleted: Number,
  learningStreak: Number,
  achievements: [Object],
  lastLoginAt: Date,
  createdAt: Date,
  updatedAt: Date
}
```

## 🔐 Authentication

### How JWT Works

1. User registers/logs in → Gets JWT token
2. Token stored in frontend
3. Each request includes token in headers
4. Server verifies token → Grants access

### Usage Example

```bash
# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password"}'

# Response includes token
# {"token":"eyJhbGciOiJIUzI1NiIs..."}

# Use token in requests
curl http://localhost:5000/api/user/profile \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 📊 Response Format

All responses follow this format:

```javascript
// Success
{
  "message": "Operation successful",
  "data": { /* response data */ }
}

// Error
{
  "error": "Error message",
  "message": "Detailed description"
}
```

## 🧪 Testing Endpoints

### Using cURL

```bash
# Signup
curl -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "name":"John Doe",
    "email":"john@example.com",
    "password":"password123"
  }'

# Get NASA APOD
curl http://localhost:5000/api/nasa/apod

# Get earthquakes
curl http://localhost:5000/api/disaster/earthquakes
```

### Using Postman

1. Download Postman
2. Create new request
3. Set URL and method
4. Add headers: `Content-Type: application/json`
5. Send request

## 🚀 Deployment

### Render (Recommended)

1. Push code to GitHub
2. Connect to Render
3. Set environment variables
4. Deploy automatically
5. Get live URL

### Vercel

```bash
vercel
# Follow prompts
# Live URL generated
```

### Heroku

```bash
heroku create your-app-name
heroku config:set MONGODB_URI=your_mongo_uri
heroku config:set NASA_API_KEY=your_key
git push heroku main
```

### AWS/DigitalOcean

1. SSH into server
2. Clone repository
3. Install dependencies
4. Set environment variables
5. Start with PM2 or systemd

## 🐛 Troubleshooting

### MongoDB Connection Failed

```bash
# Check MongoDB is running
# Local: mongod command
# Atlas: Check connection string in .env
```

### API Key Errors

```bash
# Get free NASA API: https://api.nasa.gov
# Get free OpenWeather: https://openweathermap.org/api
# Update .env with your keys
```

### Port Already in Use

```bash
# Change PORT in .env or
# Kill existing process
lsof -i :5000
kill -9 <PID>
```

## 📚 API Documentation

- [NASA APIs](https://api.nasa.gov)
- [OpenWeather API](https://openweathermap.org/api)
- [USGS Earthquake Data](https://earthquake.usgs.gov)
- [JWT Guide](https://jwt.io)
- [Express.js Docs](https://expressjs.com)
- [MongoDB Docs](https://docs.mongodb.com)

## 🔗 Connect Frontend

In your frontend `.env`:

```
VITE_API_URL=http://localhost:5000/api
# OR production URL
VITE_API_URL=https://your-api.com/api
```

In your React component:

```javascript
const API_URL = import.meta.env.VITE_API_URL;

// Signup
fetch(`${API_URL}/auth/signup`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name, email, password })
})

// Get NASA APOD
fetch(`${API_URL}/nasa/apod`)
```

## 📈 Monitoring & Logging

### View Logs

```bash
# Development
npm run dev > logs.txt

# Production (with PM2)
pm2 logs
```

### Health Check Endpoint

```bash
# Check if API is running
curl http://localhost:5000/api/health
```

## 🎯 Performance Tips

✅ Use MongoDB Atlas for production
✅ Enable caching for NASA data
✅ Optimize database queries with indexes
✅ Use CDN for static files
✅ Monitor API response times

## 📄 License

MIT License - See LICENSE file

## 🤝 Contributing

1. Fork repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📞 Support

For issues and questions:

1. Check logs for errors
2. Verify API keys
3. Test endpoints with cURL/Postman
4. Check GitHub issues
5. Email support

## 🎉 Success!

Backend successfully set up!

Next steps:
1. ✅ Connect frontend to API
2. ✅ Test all endpoints
3. ✅ Deploy to production
4. ✅ Monitor and scale
5. ✅ Add more features

---

**Built for Universal Space Live - Explore Earth, Discover Space, Learn with AI! 🌌🚀**
