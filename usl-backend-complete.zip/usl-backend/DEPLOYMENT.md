# 📖 USL Backend - Complete Setup & Deployment Guide

## 🎯 Table of Contents

1. Local Development Setup
2. Environment Configuration
3. Database Setup
4. API Keys Setup
5. Testing
6. Deployment
7. Troubleshooting
8. Production Checklist

---

## 1️⃣ Local Development Setup

### Prerequisites Installation

#### Windows

```bash
# Install Node.js
# Download from nodejs.org/en/download

# Verify installation
node --version
npm --version

# Install MongoDB
# Download from mongodb.com/try/download/community
# Or use MongoDB Atlas (cloud)
```

#### Mac

```bash
# Using Homebrew
brew install node
brew install mongodb-community

# Start MongoDB
brew services start mongodb-community

# Verify
node --version
npm --version
```

#### Linux

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install nodejs npm

# MongoDB
sudo apt-get install mongodb

# Start
sudo systemctl start mongod

# Verify
node --version
npm --version
```

### Project Setup

```bash
# 1. Extract ZIP file
unzip universal-space-live-backend.zip
cd universal-space-live-backend

# 2. Install dependencies
npm install

# 3. Copy environment template
cp .env.example .env

# 4. Edit .env
nano .env  # or use your editor

# 5. Start development server
npm run dev
```

**Expected Output:**

```
╔═══════════════════════════════════════════════════════════╗
║   🌌 Universal Space Live Backend Server                ║
║   ✅ Running on Port 5000                                ║
║   📍 http://localhost:5000                               ║
║   🌍 Database: Connected                                 ║
╚═══════════════════════════════════════════════════════════╝
```

---

## 2️⃣ Environment Configuration

### Copy Template

```bash
cp .env.example .env
```

### Edit .env File

Required variables:

```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/universal-space-live
JWT_SECRET=your-super-secret-key-change-this
NASA_API_KEY=your_nasa_key
OPENWEATHER_API_KEY=your_weather_key
CORS_ORIGIN=http://localhost:3000,http://localhost:5173
```

### Get API Keys

#### NASA API (Free)

1. Go to https://api.nasa.gov
2. Fill the form
3. Get API key instantly
4. Add to .env: `NASA_API_KEY=your_key`

#### OpenWeather API (Free)

1. Go to https://openweathermap.org/api
2. Create free account
3. Get API key
4. Add to .env: `OPENWEATHER_API_KEY=your_key`

#### Other APIs (Free/Public)

- USGS Earthquakes: Free, no key needed
- ISS Tracker: Free, no key needed
- Meteor Showers: Free, no key needed

---

## 3️⃣ Database Setup

### Local MongoDB

#### Windows

1. Download MongoDB Community
2. Run installer
3. Choose "Install MongoDB as a Windows Service"
4. MongoDB runs automatically

#### Mac

```bash
brew install mongodb-community
brew services start mongodb-community
```

#### Linux

```bash
sudo systemctl start mongod
sudo systemctl enable mongod
```

### MongoDB Atlas (Cloud)

1. Go to https://mongodb.com/cloud/atlas
2. Create free account
3. Create cluster
4. Get connection string
5. Update .env:

```env
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/universal-space-live?retryWrites=true&w=majority
```

### Verify Connection

```bash
# Test with this command
npm run dev

# Look for: ✅ MongoDB Connected: localhost
```

---

## 4️⃣ Complete .env Template

```env
# Server
PORT=5000
NODE_ENV=development
APP_URL=http://localhost:3000

# Database - Local
MONGODB_URI=mongodb://localhost:27017/universal-space-live

# Database - Cloud (MongoDB Atlas)
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/universal-space-live?retryWrites=true&w=majority

# JWT
JWT_SECRET=generate-random-string-here-min-32-chars
JWT_EXPIRE=30d

# NASA API - Get from https://api.nasa.gov
NASA_API_KEY=your_nasa_api_key

# OpenWeather API - Get from https://openweathermap.org/api
OPENWEATHER_API_KEY=your_openweather_api_key

# CORS
CORS_ORIGIN=http://localhost:3000,http://localhost:5173,https://your-frontend.vercel.app

# Logging
LOG_LEVEL=debug
```

---

## 5️⃣ Testing

### Health Check

```bash
curl http://localhost:5000/api/health

# Response:
# {"status":"OK","message":"🌌 Universal Space Live API is running!"}
```

### Test NASA APOD

```bash
curl http://localhost:5000/api/nasa/apod

# Returns latest astronomy picture
```

### Test Earthquakes

```bash
curl http://localhost:5000/api/disaster/earthquakes

# Returns recent earthquakes worldwide
```

### Test Signup

```bash
curl -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "name":"Test User",
    "email":"test@example.com",
    "password":"password123"
  }'

# Returns token and user info
```

### Using Postman

1. Download Postman: postman.com
2. Create new request
3. Set to POST
4. URL: http://localhost:5000/api/auth/signup
5. Headers: Content-Type: application/json
6. Body (JSON):
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123"
}
```
7. Send

---

## 6️⃣ Deployment Options

### Option A: Render (Recommended)

1. **Push to GitHub**
```bash
git init
git add .
git commit -m "Initial commit: USL Backend"
git branch -M main
git remote add origin https://github.com/username/usl-backend.git
git push -u origin main
```

2. **Connect to Render**
   - Go to render.com
   - Click "New +"
   - Select "Web Service"
   - Connect GitHub repo
   - Select "universal-space-live-backend"

3. **Configure**
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Environment variables:
     - Add all from .env
     - Use MongoDB Atlas for MONGODB_URI

4. **Deploy**
   - Click "Deploy"
   - Wait 2-3 minutes
   - Get live URL

**Live API URL:** `https://your-app-render.onrender.com`

### Option B: Vercel

1. **Push to GitHub** (same as above)

2. **Connect Vercel**
   - Go to vercel.com
   - "New Project"
   - Import GitHub repo
   - Select "universal-space-live-backend"

3. **Configure**
   - Framework: Node.js
   - Build Command: `npm install && npm run build`
   - Output Directory: `./`

4. **Environment Variables**
   - Add all from .env
   - Use MongoDB Atlas URI

5. **Deploy** - Click "Deploy"

### Option C: Heroku

```bash
# Install Heroku CLI
# Then:

heroku login
heroku create your-app-name
heroku config:set MONGODB_URI=your_mongo_atlas_uri
heroku config:set NASA_API_KEY=your_key
heroku config:set OPENWEATHER_API_KEY=your_key
heroku config:set JWT_SECRET=your_secret_key

git push heroku main
heroku logs --tail
```

**Live URL:** `https://your-app-name.herokuapp.com`

### Option D: DigitalOcean / AWS

1. **Create Droplet/EC2 Instance**
   - Ubuntu 20.04
   - Minimum: 1GB RAM

2. **SSH into server**
```bash
ssh root@your_ip
```

3. **Setup Node.js**
```bash
curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
sudo apt-get install -y nodejs
node --version
npm --version
```

4. **Clone Repository**
```bash
git clone https://github.com/username/usl-backend.git
cd usl-backend
npm install
```

5. **Setup Environment**
```bash
nano .env
# Add all variables
```

6. **Install PM2**
```bash
sudo npm install -g pm2
pm2 start server.js --name "usl-backend"
pm2 startup
pm2 save
```

7. **Setup Nginx** (Optional)
```bash
sudo apt-get install nginx
sudo nano /etc/nginx/sites-available/default

# Configure reverse proxy to 5000
```

8. **SSL Certificate** (Optional)
```bash
sudo apt-get install certbot python3-certbot-nginx
sudo certbot certonly --nginx -d yourdomain.com
```

---

## 7️⃣ Troubleshooting

### Port Already in Use

```bash
# Find process using port 5000
lsof -i :5000

# Kill it
kill -9 <PID>

# Or change port in .env
PORT=5001
```

### MongoDB Connection Error

```bash
# Check if MongoDB is running
ps aux | grep mongod

# If not:
# Local: mongod command
# Mac: brew services start mongodb-community
# Linux: sudo systemctl start mongod

# Or use MongoDB Atlas (cloud)
```

### API Key Errors

```
# Verify in .env:
NASA_API_KEY=your_actual_key (not DEMO_KEY)
OPENWEATHER_API_KEY=your_actual_key

# Test APIs:
curl http://localhost:5000/api/nasa/apod
curl http://localhost:5000/api/weather/current/London
```

### JWT Authentication Failed

```
# Check token in request header:
Authorization: Bearer YOUR_TOKEN

# Regenerate secret in .env if needed:
JWT_SECRET=your_new_secret_key

# Restart server
npm run dev
```

### CORS Errors

```env
# Update CORS_ORIGIN in .env
CORS_ORIGIN=http://localhost:3000,http://localhost:5173,https://your-frontend.com

# Restart server
```

---

## 8️⃣ Production Checklist

Before deploying to production:

- [ ] Change NODE_ENV to `production`
- [ ] Set strong JWT_SECRET (random 32+ chars)
- [ ] Use MongoDB Atlas for database
- [ ] Get all API keys (NASA, OpenWeather)
- [ ] Update CORS_ORIGIN to frontend URLs
- [ ] Enable HTTPS
- [ ] Setup error monitoring (Sentry)
- [ ] Configure logging
- [ ] Setup backup strategy
- [ ] Test all endpoints
- [ ] Load test the API
- [ ] Security audit

### Production .env Example

```env
PORT=5000
NODE_ENV=production
APP_URL=https://your-frontend.com

MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/usl?retryWrites=true&w=majority
JWT_SECRET=very-long-random-secret-key-minimum-32-characters
NASA_API_KEY=your_real_key
OPENWEATHER_API_KEY=your_real_key

CORS_ORIGIN=https://your-frontend.com,https://www.your-frontend.com
```

---

## 🎯 Quick Reference

| Task | Command |
|------|---------|
| Install deps | `npm install` |
| Dev server | `npm run dev` |
| Production | `npm start` |
| Test API | `curl http://localhost:5000/api/health` |
| View logs | `npm run dev` (shows logs) |
| Deploy render | Push to GitHub → Connect Render |
| MongoDB local | `mongod` |
| MongoDB Atlas | Update MONGODB_URI in .env |

---

## 📚 Resources

- [Node.js Docs](https://nodejs.org/docs)
- [Express.js Docs](https://expressjs.com)
- [MongoDB Docs](https://docs.mongodb.com)
- [NASA APIs](https://api.nasa.gov)
- [OpenWeather API](https://openweathermap.org/api)
- [JWT Explanation](https://jwt.io)
- [Render Deployment](https://render.com/docs)

---

**🎉 All set! Your USL Backend is ready to go!**

Next steps:
1. ✅ Setup local development
2. ✅ Test all endpoints
3. ✅ Deploy to production
4. ✅ Connect frontend
5. ✅ Monitor and scale
