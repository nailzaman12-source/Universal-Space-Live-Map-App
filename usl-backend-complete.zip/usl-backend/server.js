/**
 * Universal Space Live Backend
 * AI-powered educational platform for exploring Earth, Space, Weather & Disasters
 */

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
require('dotenv').config();

const app = express();

// Security & Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true
}));
app.use(compression());
app.use(morgan('combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Database Connection
const connectDB = async () => {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/usl';
    await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log(`✅ MongoDB Connected: ${mongoose.connection.host}`);
    console.log(`📦 Database: ${mongoose.connection.name}`);
  } catch (error) {
    console.error(`❌ MongoDB Error: ${error.message}`);
    process.exit(1);
  }
};

connectDB();

// Routes
const authRoutes = require('./routes/auth');
const nasaRoutes = require('./routes/nasa');
const weatherRoutes = require('./routes/weather');
const disasterRoutes = require('./routes/disaster');
const userRoutes = require('./routes/user');
const spaceEventsRoutes = require('./routes/spaceEvents');

app.use('/api/auth', authRoutes);
app.use('/api/nasa', nasaRoutes);
app.use('/api/weather', weatherRoutes);
app.use('/api/disaster', disasterRoutes);
app.use('/api/user', userRoutes);
app.use('/api/space-events', spaceEventsRoutes);

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    message: '🌌 Universal Space Live API is running!',
    timestamp: new Date(),
    version: '1.0.0'
  });
});

// API Documentation
app.get('/api/docs', (req, res) => {
  res.json({
    message: 'Universal Space Live API Documentation',
    version: '1.0.0',
    endpoints: {
      auth: '/api/auth',
      nasa: '/api/nasa',
      weather: '/api/weather',
      disaster: '/api/disaster',
      user: '/api/user',
      spaceEvents: '/api/space-events'
    },
    docs: 'https://github.com/nailzaman12-source/Universal-Space-Live-Map-App'
  });
});

// 404 Handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Route not found',
    path: req.path,
    method: req.method
  });
});

// Error Handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// Start Server
const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🌌 Universal Space Live Backend Server                ║
║   ✅ Running on Port ${PORT}                            ║
║   📍 http://localhost:${PORT}                            ║
║   🌍 Database: Connected                                 ║
║   🚀 Status: Production Ready                            ║
║                                                           ║
║   Endpoints:                                             ║
║   • /api/nasa          - NASA APOD & Data               ║
║   • /api/weather       - Real-time Weather              ║
║   • /api/disaster      - Natural Disasters              ║
║   • /api/space-events  - Space Events Tracking          ║
║   • /api/user          - User Profile & Progress        ║
║   • /api/auth          - Authentication                 ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);
});

// Graceful Shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    console.log('Server closed');
    mongoose.connection.close();
    process.exit(0);
  });
});

module.exports = app;
