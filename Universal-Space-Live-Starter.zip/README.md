# Universal Space Live

AI-powered educational platform concept for exploring Earth, space, weather, satellites, natural events and future real-time universal data.

## Included
- Mobile-friendly frontend
- Earth, Weather, Satellites, Disasters, AI and Analytics cards
- Universal map placeholder
- Responsive HTML/CSS/JavaScript

## Next
Connect verified live APIs, interactive maps, satellite feeds and backend services.

Educational project only; no weaponized functionality.
