function dash(){document.getElementById('dashboard').scrollIntoView({behavior:'smooth'});}
document.getElementById('refresh').onclick=()=>location.reload();