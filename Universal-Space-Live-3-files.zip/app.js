// Universal Space Live
// Main navigation and interactive controls

document.addEventListener("DOMContentLoaded", () => {
  const sections = document.querySelectorAll(".section");
  const navButtons = document.querySelectorAll(".nav-btn");
  const sectionButtons = document.querySelectorAll("[data-section]");
  const menuButton = document.getElementById("menuButton");
  const exploreButton = document.getElementById("exploreButton");
  const aiButton = document.getElementById("aiButton");
  const aiMessage = document.getElementById("aiMessage");

  function showSection(sectionId) {
    sections.forEach(section => {
      section.classList.toggle("active", section.id === sectionId);
    });

    navButtons.forEach(button => {
      button.classList.toggle(
        "active",
        button.dataset.section === sectionId
      );
    });

    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  }

  sectionButtons.forEach(button => {
    button.addEventListener("click", () => {
      const sectionId = button.dataset.section;
      if (sectionId) showSection(sectionId);
    });
  });

  if (exploreButton) {
    exploreButton.addEventListener("click", () => {
      showSection("space");
    });
  }

  if (menuButton) {
    menuButton.addEventListener("click", () => {
      const navigation = document.querySelector(".navigation");

      if (navigation) {
        navigation.classList.toggle("open");
      }
    });
  }

  navButtons.forEach(button => {
    button.addEventListener("click", () => {
      showSection(button.dataset.section);

      const navigation = document.querySelector(".navigation");
      if (navigation) {
        navigation.classList.remove("open");
      }
    });
  });

  if (aiButton && aiMessage) {
    aiButton.addEventListener("click", () => {
      aiMessage.textContent =
        "🤖 Educational AI is ready. Live AI data analysis will be connected in a future development stage.";
      aiMessage.classList.add("show");
    });
  }

  // Simple animated satellite movement
  const satellites = document.querySelectorAll(".satellite");
  satellites.forEach((satellite, index) => {
    satellite.style.animationDelay = `${index * 1.5}s`;
  });

  // Make sure Dashboard is visible on first load
  showSection("dashboard");
});
