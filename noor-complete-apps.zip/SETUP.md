# 🚀 Setup Guide - Live Universal Space Map

## Quick Start (5 Minutes)

### Step 1: Initialize Project
```bash
# Create project directory
mkdir space-map && cd space-map

# Copy all files to this directory
# Then run:
npm install
```

### Step 2: Start Development Server
```bash
npm run dev
```

The app will be available at `http://localhost:5173`

### Step 3: Build for Production
```bash
npm run build
npm run preview
```

---

## File-by-File Setup

### Essential Files (Required)

1. **app.js** ✅
   - React entry point
   - Location: Root directory
   - Purpose: Initializes the React application

2. **SpaceMapApp.jsx** ✅
   - Main component with all features
   - Location: Root directory
   - Purpose: Contains all app logic and UI

3. **SpaceMap.css** ✅
   - Application styles
   - Location: Root directory
   - Purpose: Complete styling and animations

4. **index.html** ✅
   - HTML template
   - Location: Root directory
   - Purpose: Main HTML file for the web app

5. **package.json** ✅
   - Dependencies configuration
   - Location: Root directory
   - Purpose: Manages npm packages

### Optional Utility Files

6. **screen.js** (Optional)
   - Device and screen utilities
   - Location: Root directory
   - Purpose: Helper functions for responsive design
   - Usage: Import and use utility functions

---

## Installation Methods

### Method 1: Using Vite (Recommended)

```bash
# Install Node.js first (if not installed)
# Then:

npm install
npm run dev
```

### Method 2: Using Create React App

```bash
npx create-react-app space-map
cd space-map

# Copy the three main files:
# - SpaceMapApp.jsx → src/SpaceMapApp.jsx
# - SpaceMap.css → src/SpaceMap.css
# - app.js → Update src/index.js

npm start
```

### Method 3: Using CDN (Simple Way)

```html
<!-- In index.html, use React CDN -->
<script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
<script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>

<!-- Then include your components -->
<script src="SpaceMapApp.jsx"></script>
```

---

## Folder Structure

```
space-map/
│
├── 📄 app.js                 (Entry point)
├── 📄 index.html             (HTML template)
├── 📄 package.json           (Dependencies)
│
├── 📁 src/                   (Source files)
│   ├── SpaceMapApp.jsx       (Main component)
│   └── SpaceMap.css          (Styles)
│
├── 📁 public/                (Static assets)
│   └── index.html
│
└── 📁 dist/                  (Build output)
    ├── index.html
    ├── app.js
    └── style.css
```

---

## Configuration

### Change Event Generation Speed

**File**: `SpaceMapApp.jsx`

```javascript
// Line ~60
const interval = setInterval(() => {
  // ...
}, 5000);  // Change 5000 to desired milliseconds
```

### Adjust Canvas Size

**File**: `SpaceMapApp.jsx`

```javascript
// Line ~250
<canvas 
  ref={canvasRef} 
  width={800}    // ← Change width
  height={600}   // ← Change height
/>
```

### Customize Colors

**File**: `SpaceMap.css`

```css
/* Change primary color */
/* Search for #00bfff and replace with your color */
```

### Modify Event Types

**File**: `SpaceMapApp.jsx`

```javascript
// Line ~55
const eventTypes = ['asteroid', 'solar_flare', 'station_alert', 'comet', 'meteor'];
// Add or remove event types
```

---

## Running on Different Servers

### Local Development
```bash
npm run dev
```

### Production Build
```bash
npm run build
npm run preview
```

### Deploy to Vercel
```bash
npm install -g vercel
vercel
```

### Deploy to Netlify
```bash
npm run build
# Upload dist/ folder to Netlify
```

### Deploy to GitHub Pages
```bash
npm run build
# Upload dist/ folder to gh-pages branch
```

---

## Customization Examples

### Example 1: Add New Event Type

```javascript
// In SpaceMapApp.jsx, add to eventTypes array:
const eventTypes = [..., 'supernova', 'black_hole'];

// Add color mapping in the draw function:
const colors = {
  supernova: '#FFFF00',
  black_hole: '#000000',
  // ... existing colors
};
```

### Example 2: Change Update Frequency

```javascript
// For more frequent updates:
const interval = setInterval(() => {
  // ...
}, 2000);  // Every 2 seconds instead of 5

// For less frequent:
const interval = setInterval(() => {
  // ...
}, 10000);  // Every 10 seconds
```

### Example 3: Modify Report Types

```javascript
// In the report form select:
<select>
  <option value="disaster">Disaster</option>
  <option value="anomaly">Anomaly</option>
  <option value="observation">Observation</option>
  <option value="alert">Alert</option>
  <option value="discovery">Discovery</option>  // New option
  <option value="warning">Warning</option>      // New option
</select>
```

---

## Environment Variables

Create a `.env` file:

```env
VITE_API_URL=http://localhost:3000
VITE_WEBSOCKET_URL=ws://localhost:3001
VITE_APP_NAME=Space Map
```

Access in code:
```javascript
const apiUrl = import.meta.env.VITE_API_URL;
```

---

## Troubleshooting

### Issue: Port 5173 already in use
```bash
npm run dev -- --port 3000
```

### Issue: Module not found
```bash
rm -rf node_modules
npm install
```

### Issue: CSS not loading
- Ensure SpaceMap.css is in the same directory
- Check the import path in SpaceMapApp.jsx
- Try clearing browser cache (Ctrl+Shift+Delete)

### Issue: Canvas showing blank
- Check browser console for errors
- Verify canvas ref is mounted
- Check if JavaScript is enabled
- Try different browser

---

## Testing

### Manual Testing Checklist
- [ ] Canvas displays space map
- [ ] Events appear in real-time
- [ ] Can create reports
- [ ] Can view analytics
- [ ] Responsive on mobile
- [ ] Animations smooth at 60fps
- [ ] No console errors

### Browser Testing
- [ ] Chrome/Chromium
- [ ] Firefox
- [ ] Safari
- [ ] Edge
- [ ] Mobile browsers

---

## Performance Optimization

### Tips for Better Performance

1. **Reduce event generation frequency**
   - Increase interval time (default 5000ms)

2. **Optimize canvas rendering**
   - Reduce number of drawn elements
   - Use requestAnimationFrame efficiently

3. **Lazy load components**
   - Load reports/analytics on demand

4. **Bundle optimization**
   ```bash
   npm run build  # Automatically optimizes
   ```

5. **Enable compression**
   - GZip compression on server

---

## Next Steps

1. ✅ Install dependencies: `npm install`
2. ✅ Start development: `npm run dev`
3. ✅ Test in browser
4. ✅ Customize as needed
5. ✅ Build for production: `npm run build`
6. ✅ Deploy to hosting

---

## Getting Help

- 📖 Read README.md for features
- 💬 Check screen.js for utility functions
- 🔍 Review comments in SpaceMapApp.jsx
- 🐛 Check browser console for errors

---

**Happy space exploring! 🌌**
