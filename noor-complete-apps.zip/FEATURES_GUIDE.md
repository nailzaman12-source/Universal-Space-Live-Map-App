# 💰 EarnHub - Features Guide

Complete guide to all features and how to use them.

---

## 📊 Dashboard Tab

### What You'll See:

**Profile Card**
- Your name
- Join date
- Current level
- Level progress bar

**Statistics Card**
- Tasks completed
- Referrals count
- Withdrawals count
- Total withdrawn amount

**Daily Bonus Card**
- ₹20 bonus available
- "Claim Bonus" button
- Claim daily without limit

**Quick Stats**
- Daily average earnings
- Time spent on app
- Reputation rating

### How to Use:

1. **Check Balance**
   - Total earnings shown at top
   - Available balance displayed
   - Real-time updates

2. **Claim Daily Bonus**
   - Click "Claim Bonus" button
   - Instantly earn ₹20
   - Can claim every day

3. **Track Progress**
   - See level progress bar
   - Watch earnings grow
   - Monitor statistics

---

## 📝 Tasks Tab

### Available Tasks:

| Task | Reward | Category | Expiry |
|------|--------|----------|--------|
| Daily Login | ₹10 | Daily | 24 hours |
| Complete Profile | ₹50 | Profile | No expiry |
| Invite 3 Friends | ₹100 | Referral | No expiry |
| Watch Video (30s) | ₹5 | Video | 2 hours |
| Survey Completion | ₹25 | Survey | No expiry |
| Play Mini Game | ₹15 | Game | 12 hours |

### How to Complete Tasks:

1. **Browse Tasks**
   - All available tasks shown
   - See reward amount
   - Check expiry time

2. **Complete Task**
   - Click "Complete Task" button
   - Task completed immediately
   - Reward added to balance
   - ✅ Mark as complete

3. **Track Progress**
   - Completed tasks show ✅
   - Cannot complete twice
   - New tasks appear daily

### Earning Strategy:

**Best Money-Making Tasks (Per Day):**
1. Daily Login - ₹10 (daily)
2. Watch Videos - ₹5 × 4 = ₹20 (daily)
3. Surveys - ₹25 (whenever available)
4. Mini Games - ₹15 (daily)

**Maximum Daily from Tasks: ₹70+**

---

## 👥 Referral Tab

### How Referral Program Works:

**Earn ₹50 Per Friend**

```
You → Share Code → Friend Joins → You Earn ₹50
```

### Your Referral Code:

```
REF123ABC
```

**How to Use:**
1. Copy your code (📋 button)
2. Share with friends
3. Friend uses your code to join
4. You earn ₹50 instantly!

### Track Referrals:

**See All Your Referrals:**
- Friend's name
- Join date
- Their earnings

**Example Referrals:**
- Ali Khan - Joined 7 days ago - ₹150 earned
- Fatima Ahmed - Joined 3 days ago - ₹75 earned

### Ways to Share:

1. **WhatsApp**
   - Copy code → Share in message
   - "Join EarnHub with code: REF123ABC"

2. **Facebook**
   - Post referral code
   - Friends see and join

3. **Instagram**
   - Share in bio link
   - Stories mentioning code

4. **SMS/Email**
   - Direct personal share
   - Most effective!

5. **Direct Share**
   - Copy button → Share anywhere

### Referral Bonus:

**Unlimited Earnings!**
- No limit on referrals
- Get ₹50 per friend
- Earn from their earnings too (optional tier)

**Example Earnings:**
- 10 referrals = ₹500
- 50 referrals = ₹2,500
- 100 referrals = ₹5,000

---

## 🏧 Withdraw Tab

### Withdrawal Process:

**Step 1: Enter Amount**
- Minimum: ₹100
- Maximum: Your available balance
- Use quick buttons or type

**Step 2: Select Payment Method**
Options:
- Bank Transfer
- JazzCash (Pakistan)
- Easypaisa (Pakistan)
- Google Pay

**Step 3: Request Withdrawal**
- Click "Request Withdrawal"
- Confirmation shown
- Amount deducted from balance

**Step 4: Wait for Processing**
- Pending status shows
- Usually processed in 24-48 hours
- Completed status when done

### Quick Amount Buttons:

- ₹100
- ₹500
- ₹1,000
- All (entire balance)

### Payment Methods:

**Bank Transfer**
- Takes 2-3 days
- Direct to your bank account
- Needs bank details

**JazzCash (Pakistan)**
- Instant transfer
- To any JazzCash account
- Needs JazzCash number

**Easypaisa (Pakistan)**
- 30 minutes processing
- To Easypaisa account
- Needs Easypaisa number

**Google Pay**
- Instant
- To Google Pay account
- Needs Google Pay ID

### Withdrawal History:

**See All Your Withdrawals:**
- Amount withdrawn
- Date requested
- Status (Pending/Completed)

**Example:**
```
₹500 - Jan 15, 2024 - COMPLETED
₹300 - Jan 20, 2024 - PENDING
```

### Tips:

✅ **Do:**
- Withdraw regularly
- Use preferred payment method
- Save referral code for later

❌ **Don't:**
- Try to withdraw less than ₹100
- Provide fake payment details
- Withdraw more than balance

---

## 🏆 Leaderboard Tab

### See Top Earners:

**Rank #1: Muhammad Hassan**
- 🥇 Gold Medal
- Earnings: ₹5,000

**Rank #2: Ayesha Khan**
- 🥈 Silver Medal
- Earnings: ₹4,500

**Rank #3: Ali Raza**
- 🥉 Bronze Medal
- Earnings: ₹4,200

**Rank #4-5+: Others**
- Numbered positions
- Various earnings

**Your Position:**
- Shows where you rank
- Motivates to earn more

### Use Leaderboard To:

1. **Get Motivated**
   - See what others earned
   - Set personal goals
   - Compete friendly

2. **Track Progress**
   - See your rank
   - Watch ranking improve
   - Get inspired

3. **Learn Strategies**
   - See top earners
   - Find best earning methods
   - Follow their example

---

## 💡 Money-Making Strategies

### Strategy 1: Task-Based (Beginner)

**Daily Routine:**
1. Login for ₹10
2. Claim bonus for ₹20
3. Complete 4 videos for ₹20
4. Do 1 survey for ₹25
5. Play game for ₹15

**Daily Earning: ₹90**
**Weekly: ₹630**
**Monthly: ₹2,700**

### Strategy 2: Referral-Focused (Intermediate)

**Share referral code:**
- 10 friends × ₹50 = ₹500
- Plus tasks = ₹90

**Daily Earning: ₹90**
**Plus referrals: ₹500 (per 10 friends)**
**Monthly (10 friends): ₹2,700 + ₹500 = ₹3,200**

### Strategy 3: Combined (Advanced)

**Do everything:**
- Daily tasks: ₹90/day
- Daily bonus: ₹20/day
- Referrals: ₹50 each
- Leaderboard: Bonus rewards

**With 50 referrals:**
- Tasks: ₹90/day
- Bonus: ₹20/day
- Referrals: ₹2,500 (one time)

**Monthly: ₹3,300 + ₹2,500 = ₹5,800**

### Pro Tips:

✅ **Maximize Earnings:**
- Complete all daily tasks
- Share referral code daily
- Invite quality friends
- Claim bonus every day
- Use best payment method

---

## 🎁 Bonus Features

### Daily Streak Bonus

Come back every day:
- Day 1: ₹20 bonus
- Day 7: Extra ₹50
- Day 30: Extra ₹200

**Tip:** Don't miss a day!

### Level System

Progress through levels:
- Level 1: Start
- Level 2: 20 tasks
- Level 3: ₹1,000 earned
- Level 4: 10 referrals

**Benefits:**
- Unlock better tasks
- Higher rewards
- Special bonuses

### Reputation Rating

Build your reputation:
- Complete tasks on time
- Don't cheat system
- Help others earn
- Share referral code

**Rating Shown:**
- 5.0 = Excellent
- 4.5 = Very Good
- 4.0 = Good

---

## ⏱️ Time Required

### Earning Estimates:

**Per Day:**
- 30 minutes minimum
- Tasks: 20 minutes
- Referral sharing: 10 minutes

**Per Week:**
- 3.5 hours
- Multiple referral invites
- Daily bonus claiming

**Per Month:**
- 14+ hours
- Steady income stream
- 50+ referrals ideal

### Best Times to Earn:

**Task Availability:**
- Morning: 6 AM - 9 AM
- Afternoon: 1 PM - 4 PM
- Evening: 6 PM - 9 PM

**Withdrawal Speed:**
- Request by: Friday evening
- Receive by: Monday morning

---

## ❓ FAQ

**Q: Can I earn without referrals?**
A: Yes! Tasks alone give ₹50-100/day

**Q: What's minimum withdrawal?**
A: ₹100

**Q: How long for payment?**
A: 24-48 hours usually

**Q: Can I have multiple accounts?**
A: No, against terms of service

**Q: Best payment method?**
A: JazzCash/Easypaisa (fastest)

**Q: How many times daily bonus?**
A: Once per 24 hours

**Q: Are tasks unlimited?**
A: New ones appear daily

**Q: Can I withdraw before earning?**
A: No, need ₹100+ balance

---

## 🚀 Getting Started Checklist

- [ ] Download and install app
- [ ] Copy your referral code
- [ ] Share with friends
- [ ] Complete first task
- [ ] Claim daily bonus
- [ ] Monitor earnings
- [ ] Request first withdrawal
- [ ] Set withdrawal method
- [ ] Check leaderboard
- [ ] Read tips and tricks

---

## 💬 Need Help?

**Common Issues:**

**Can't complete task?**
- Refresh browser
- Clear cache
- Try again in 5 minutes

**Balance not updating?**
- Wait 30 seconds
- Refresh page
- Check console for errors

**Withdrawal not processing?**
- Check details are correct
- Confirm payment method
- Wait 48 hours

**Referral not counting?**
- Friend needs to complete signup
- Must use your exact code
- May take a few hours

---

**Ready to earn? Start with the Dashboard! 💰**

Join thousands earning on EarnHub today!
