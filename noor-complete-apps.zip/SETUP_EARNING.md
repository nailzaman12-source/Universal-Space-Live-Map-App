# 🚀 EarnHub Setup Guide

Complete step-by-step setup instructions for the Earning App.

## ⚡ 5-Minute Quick Start

```bash
# 1. Download files
# 2. Open terminal in project folder
# 3. Run:
npm install
npm run dev

# 4. Open http://localhost:5173
```

Done! App is running! 🎉

---

## 📋 Complete Setup Steps

### Step 1: Install Node.js
1. Download from https://nodejs.org/
2. Install (latest LTS version recommended)
3. Verify installation:
```bash
node --version
npm --version
```

### Step 2: Setup Project
```bash
# Create project folder
mkdir earnhub
cd earnhub

# Copy all files from downloaded files
# Then run:
npm install
```

### Step 3: Start Development
```bash
npm run dev
```

Browser will open automatically at `http://localhost:5173`

### Step 4: Build for Production
```bash
npm run build
```

Production files will be in `dist/` folder

---

## 📁 Files Overview

### Essential Files (Required)

1. **EarningApp.jsx** ✅
   - Main React component
   - All app logic and features
   - State management

2. **EarningApp.css** ✅
   - Complete styling
   - Responsive design
   - Animations

3. **app_earning.js** ✅
   - React entry point
   - Service worker setup
   - Error handling

4. **index_earning.html** ✅
   - HTML template
   - React mount point
   - Loading screen

5. **package.json** ✅
   - Dependencies
   - Scripts
   - Configuration

---

## 🔧 Configuration

### Change App Name

**File**: `index_earning.html`
```html
<title>💰 EarnHub - Earn Money Online</title>  <!-- Change title -->
```

### Adjust Rewards

**File**: `EarningApp.jsx` (around line 20)
```javascript
const tasks = [
  {
    id: 1,
    title: 'Daily Login',
    reward: 10,  // ← Change this
  },
  // ...
];
```

### Modify Colors

**File**: `EarningApp.css`
```css
/* Find and replace gradient colors */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Examples */
Green:   linear-gradient(135deg, #00C853 0%, #00B342 100%);
Blue:    linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
Orange:  linear-gradient(135deg, #FF9800 0%, #F57C00 100%);
Red:     linear-gradient(135deg, #F44336 0%, #D32F2F 100%);
```

### Change Minimum Withdrawal

**File**: `EarningApp.jsx` (around line 400)
```javascript
if (amount >= 100) {  // Change 100 to desired amount
  // Process withdrawal
}
```

### Add Payment Methods

**File**: `EarningApp.jsx` (around line 280)
```javascript
<select className="input-field">
  <option>Bank Transfer</option>
  <option>JazzCash</option>
  <option>Easypaisa</option>
  <option>Google Pay</option>
  <option>Bitcoin</option>  {/* Add here */}
  <option>Stripe</option>   {/* Add here */}
</select>
```

### Customize Referral Bonus

**File**: `EarningApp.jsx` (around line 230)
```javascript
const bonus = 50;  // Change to your desired amount
```

---

## 🎯 Task Customization

### Add New Task Type

**File**: `EarningApp.jsx`

```javascript
const tasks = [
  // ... existing tasks
  {
    id: 7,
    title: 'Your New Task',
    description: 'Task description here',
    reward: 20,
    category: 'new_type',
    completed: false,
    expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
  },
];
```

### Add New Reward Tier

Create bonus milestones:
```javascript
if (user.totalEarnings >= 5000) {
  // Gold tier - 10% bonus
  bonus *= 1.1;
}
if (user.totalEarnings >= 10000) {
  // Platinum tier - 20% bonus
  bonus *= 1.2;
}
```

---

## 💻 Deployment Options

### Option 1: Vercel (Easiest)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel
```

Deployed in seconds! ⚡

### Option 2: Netlify

```bash
# Build
npm run build

# Go to netlify.com
# Drag and drop 'dist' folder
```

Done! 🎉

### Option 3: GitHub Pages

```bash
# Update package.json
"homepage": "https://yourusername.github.io/earnhub"

# Build and deploy
npm run build
gh-pages -d dist
```

### Option 4: Self-Hosted

```bash
# Build
npm run build

# Upload 'dist' folder to your server
# Keep index.html in root directory
# All paths should work fine
```

---

## 🔐 Security Setup

### Environment Variables

Create `.env` file:
```env
VITE_API_URL=https://api.earnhub.com
VITE_APP_NAME=EarnHub
VITE_MIN_WITHDRAWAL=100
VITE_REFERRAL_BONUS=50
```

Access in code:
```javascript
const apiUrl = import.meta.env.VITE_API_URL;
const minWithdrawal = import.meta.env.VITE_MIN_WITHDRAWAL;
```

### Protect Routes

For future backend integration:
```javascript
// Check if user is authenticated
if (!user.authenticated) {
  return <LoginPage />;
}
```

---

## 📊 Database Schema (For Backend)

### Users Table
```sql
CREATE TABLE users (
  id INT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  phone VARCHAR(20),
  totalEarnings DECIMAL(10, 2),
  availableBalance DECIMAL(10, 2),
  withdrawnAmount DECIMAL(10, 2),
  level INT,
  referralCode VARCHAR(50),
  joinDate DATETIME,
  status VARCHAR(20)
);
```

### Tasks Table
```sql
CREATE TABLE user_tasks (
  id INT PRIMARY KEY,
  userId INT,
  taskId INT,
  completedDate DATETIME,
  earnedAmount DECIMAL(10, 2),
  status VARCHAR(20),
  FOREIGN KEY (userId) REFERENCES users(id)
);
```

### Referrals Table
```sql
CREATE TABLE referrals (
  id INT PRIMARY KEY,
  referrerId INT,
  referredUserId INT,
  joinDate DATETIME,
  earnings DECIMAL(10, 2),
  FOREIGN KEY (referrerId) REFERENCES users(id),
  FOREIGN KEY (referredUserId) REFERENCES users(id)
);
```

### Withdrawals Table
```sql
CREATE TABLE withdrawals (
  id INT PRIMARY KEY,
  userId INT,
  amount DECIMAL(10, 2),
  paymentMethod VARCHAR(50),
  status VARCHAR(20),
  requestDate DATETIME,
  completedDate DATETIME,
  transactionId VARCHAR(100),
  FOREIGN KEY (userId) REFERENCES users(id)
);
```

---

## 🔌 Backend Integration

### API Endpoints (To Create)

```
GET  /api/user/profile         - Get user data
POST /api/task/complete        - Mark task complete
POST /api/referral/create      - Create referral
POST /api/withdrawal/request   - Request withdrawal
GET  /api/leaderboard          - Get top earners
```

### Connect to Backend

**Example**:
```javascript
// In EarningApp.jsx
const completeTask = async (taskId) => {
  const response = await fetch('/api/task/complete', {
    method: 'POST',
    body: JSON.stringify({ userId: user.id, taskId })
  });
  
  const data = await response.json();
  setUser(prev => ({
    ...prev,
    totalEarnings: data.totalEarnings
  }));
};
```

---

## 🧪 Testing

### Manual Testing Checklist

- [ ] Dashboard displays correctly
- [ ] Can complete tasks
- [ ] Balance updates properly
- [ ] Referral code copies
- [ ] Can request withdrawal
- [ ] Leaderboard shows users
- [ ] Responsive on mobile
- [ ] No console errors

### Browser Testing

- [ ] Chrome/Chromium
- [ ] Firefox
- [ ] Safari
- [ ] Edge
- [ ] Mobile Safari
- [ ] Chrome Mobile

---

## ⚡ Performance Tips

### Optimize Images
```bash
npm install imagemin
```

### Lazy Load Components
```javascript
import { lazy, Suspense } from 'react';

const LeaderboardTab = lazy(() => import('./LeaderboardTab'));

<Suspense fallback={<div>Loading...</div>}>
  <LeaderboardTab />
</Suspense>
```

### Enable Gzip Compression
```bash
# In server configuration
gzip on;
gzip_types text/html text/css text/javascript;
```

---

## 📱 Mobile Optimization

### Add to Home Screen (PWA)

Update `index_earning.html`:
```html
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="EarnHub">
<link rel="apple-touch-icon" href="icon-192x192.png">
```

### Test on Mobile
```bash
# Get local IP
ipconfig getifaddr en0  # macOS
ipconfig  # Windows

# Access from phone on same network
http://YOUR_IP:5173
```

---

## 🐛 Debugging

### Enable Console Logging

**File**: `app_earning.js`
```javascript
console.log('💰 EarnHub Started');
console.log('User:', user);
console.log('Tasks:', tasks);
```

### React DevTools
- Install React DevTools extension
- Inspect component state
- Check props

### Performance Profiler
- Open DevTools
- Go to Performance tab
- Record interactions
- Analyze

---

## 🆘 Troubleshooting

### Issue: Port Already in Use
```bash
# Use different port
npm run dev -- --port 3000
```

### Issue: Module Not Found
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Issue: CSS Not Applied
- Check file path in import
- Clear browser cache (Ctrl+Shift+Delete)
- Hard refresh (Ctrl+Shift+R)

### Issue: React Not Rendering
- Check #root div exists in HTML
- Verify React import
- Check for JavaScript errors

---

## 📈 Monitoring

### Track User Engagement
```javascript
// Log user actions
const logEvent = (event, data) => {
  console.log(`[${new Date().toISOString()}] ${event}:`, data);
  // Send to analytics service
};
```

### Monitor Earnings
```javascript
// Track total earnings
const totalEarnings = user.totalEarnings;
const dailyAverage = totalEarnings / daysActive;
```

---

## 📚 Resources

- **React**: https://react.dev
- **Vite**: https://vitejs.dev
- **CSS Tricks**: https://css-tricks.com
- **MDN Web Docs**: https://developer.mozilla.org
- **Stack Overflow**: https://stackoverflow.com

---

## ✅ Deployment Checklist

Before going live:

- [ ] All files copied
- [ ] Dependencies installed
- [ ] App runs locally
- [ ] No console errors
- [ ] Mobile responsive
- [ ] Tested on browsers
- [ ] Security checked
- [ ] Optimized images
- [ ] API endpoints ready (if backend)
- [ ] Environment variables set

---

## 🎉 You're All Set!

Your EarnHub application is ready to go! 

**Next Steps**:
1. ✅ Run `npm run dev`
2. ✅ Start earning
3. ✅ Invite friends
4. ✅ Enjoy! 💰

---

**Need Help?** Check README_EARNING.md or create an issue on GitHub.

Happy earning! 🚀💵
