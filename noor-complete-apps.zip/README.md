# 🌌 Live Universal Space Map

**Real-time Space Event Tracking & Disaster Reporting System**

A comprehensive web application for monitoring space events, tracking disasters, and managing reports across the entire universe. Built with React and Canvas for real-time visualization.

## ✨ Features

### 📍 Space Map
- **Real-time visualization** of space events on an interactive canvas
- **3D coordinate system** (X, Y, Z axes)
- **Multiple event types**: Asteroids, Solar Flares, Station Alerts, Comets, Meteors
- **Severity indicators**: High, Medium, Low
- **Live event streaming**: New events appear every 5 seconds
- **Interactive markers**: Click events to see detailed information
- **Animated effects**: Pulsing markers for high-severity events

### 📋 Report System
- **Create detailed reports** for disasters and anomalies
- **Multiple report types**: Disaster, Anomaly, Observation, Alert
- **Location tracking**: Record exact coordinates and regions
- **Severity classification**: Categorize incidents
- **Timestamp recording**: Automatic time logging
- **Report history**: View all submitted reports

### 📊 Analytics Dashboard
- **Real-time statistics**: Total events, critical threats, active incidents
- **Event distribution**: Visual charts showing event type breakdown
- **Performance metrics**: Monitor system activity
- **Trend analysis**: Track patterns over time

### 🎨 UI Features
- **Modern design** with space theme
- **Responsive layout**: Works on mobile, tablet, laptop, desktop
- **Dark mode optimized**: Eye-friendly for long sessions
- **Smooth animations**: Professional transitions and effects
- **Touch-friendly**: Optimized for mobile devices
- **Accessibility**: WCAG compliant

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/space-map.git
cd space-map

# Install dependencies
npm install

# Start the development server
npm run dev
```

The application will open at `http://localhost:5173`

### Build for Production

```bash
# Build the application
npm run build

# Preview production build
npm run preview
```

## 📁 Project Structure

```
space-map/
├── app.js                 # Main React app entry point
├── SpaceMapApp.jsx        # Main React component
├── SpaceMap.css           # Application styles
├── screen.js              # Screen management & utilities
├── index.html             # HTML template
├── package.json           # Dependencies
└── README.md              # Documentation
```

### File Descriptions

**app.js**
- React application entry point
- Initializes the root React element
- Handles service worker registration
- Sets up global error handling

**SpaceMapApp.jsx**
- Main React component
- Manages state for events, reports, and UI
- Implements canvas animation
- Handles user interactions

**screen.js**
- Device and screen utilities
- Responsive design helpers
- Performance monitoring
- Storage management
- Network status tracking
- Keyboard shortcuts

**SpaceMap.css**
- Complete styling for the application
- Responsive breakpoints
- Theme colors and animations
- Component-specific styles

## 🎮 Usage

### Navigation
- **Space Map Tab**: View real-time space events on the interactive canvas
- **Reports Tab**: Create and manage incident reports
- **Analytics Tab**: View statistics and performance metrics

### Creating Reports

1. Go to **Reports** tab
2. Fill in the report details:
   - Select report type (Disaster, Anomaly, Observation, Alert)
   - Enter report title
   - Add detailed description
   - Specify location
   - Set severity level
3. Click **Submit Report**

### Viewing Events

- Events appear automatically on the space map
- Click any event marker to see detailed information
- Color-coded by type:
  - 🔴 Red: Asteroids
  - 🟠 Orange: Solar Flares
  - 🟢 Green: Station Alerts
  - 🟣 Purple: Comets
  - 🌸 Pink: Meteors

### Analytics

View statistics including:
- Total number of events
- Critical event count
- Total reports submitted
- Event distribution charts

## ⚙️ Configuration

### Canvas Size
Modify canvas dimensions in `SpaceMapApp.jsx`:
```javascript
<canvas 
  ref={canvasRef} 
  width={800}    // Adjust width
  height={600}   // Adjust height
/>
```

### Event Generation Frequency
Change event generation interval (default: 5 seconds):
```javascript
const interval = setInterval(() => {
  // ... event generation code
}, 5000);  // Change this value
```

### Event Types
Customize event types in the initialization:
```javascript
const eventTypes = ['asteroid', 'solar_flare', 'station_alert', 'comet', 'meteor'];
```

## 🔧 Advanced Features

### Screen Utilities (screen.js)

```javascript
import { ScreenUtils, ScreenConfig } from './screen.js';

// Get device type
const device = ScreenConfig.getDeviceType(); // 'mobile', 'tablet', 'laptop', 'desktop'

// Listen for screen resize
const unsubscribe = ScreenUtils.onResize((dimensions) => {
  console.log('Screen resized:', dimensions);
});

// Request fullscreen
ScreenUtils.requestFullscreen();

// Check network status
const isOnline = NetworkUtils.isOnline();
```

### Storage

```javascript
import { StorageUtils } from './screen.js';

// Save application state
StorageUtils.saveState(appState);

// Load application state
const state = StorageUtils.loadState();

// Save with expiration
StorageUtils.setWithExpiration('key', value, 3600000); // 1 hour
```

### Notifications

```javascript
import { NotificationUtils } from './screen.js';

// Request permission
await NotificationUtils.requestPermission();

// Send notification
NotificationUtils.sendNotification('Alert', {
  body: 'New space event detected!'
});
```

## 📱 Responsive Design

The application uses a mobile-first approach with breakpoints:

- **Mobile** (≤480px)
- **Tablet** (≤768px)
- **Laptop** (≤1024px)
- **Desktop** (>1024px)

Each breakpoint optimizes:
- Layout and spacing
- Font sizes
- Canvas dimensions
- Component visibility

## 🔒 Browser Support

- Chrome/Chromium 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📊 Performance

- **Canvas FPS**: 60fps animation
- **Event Update**: Real-time streaming
- **Memory**: Optimized for long-running sessions
- **Bundle Size**: ~50KB (gzipped)

## 🔐 Data Privacy

- All data stored locally in browser
- No server communication by default
- Optional: Implement backend API for data persistence
- Service Worker for offline support

## 🐛 Troubleshooting

### Canvas not displaying
- Check browser console for errors
- Ensure canvas ref is properly mounted
- Verify CSS is loaded correctly

### Events not appearing
- Check browser console for JavaScript errors
- Verify event generation interval is running
- Check network tab for any failed requests

### Performance issues
- Reduce canvas size
- Increase event generation interval
- Close other browser tabs
- Check available system memory

## 📈 Future Enhancements

- [ ] Backend API integration
- [ ] Real NASA/space agency data integration
- [ ] WebSocket for true real-time updates
- [ ] User authentication system
- [ ] Report sharing and collaboration
- [ ] Advanced filtering and search
- [ ] Data export functionality
- [ ] 3D visualization with Three.js
- [ ] Mobile app (React Native)
- [ ] Multi-language support

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see LICENSE file for details.

## 👨‍💼 Support

For issues, questions, or suggestions:
- Open an issue on GitHub
- Email: support@spacemap.dev
- Documentation: https://spacemap.dev/docs

## 🙏 Acknowledgments

- Built with React 18
- Canvas API for visualization
- Inspired by real-time monitoring systems

---

**Made with ❤️ for space enthusiasts and disaster management professionals**

🌌 *Tracking the universe, one event at a time.*
