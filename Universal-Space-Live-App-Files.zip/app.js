const $=s=>document.querySelector(s);
function updateClock(){const d=new Date();$('#clock').textContent=d.toISOString().slice(11,19)+' UTC'}
function updateDemo(){ $('#earthTemp').textContent=(22+Math.floor(Math.random()*6))+'°C'; $('#satCount').textContent=(1800+Math.floor(Math.random()*90)).toLocaleString(); $('#eventCount').textContent=5+Math.floor(Math.random()*6); $('#alertCount').textContent=2+Math.floor(Math.random()*4); updateClock(); }
setInterval(updateClock,1000); setInterval(updateDemo,7000); updateDemo();

document.querySelectorAll('.module').forEach(btn=>btn.addEventListener('click',()=>{
  $('#modalTitle').textContent=btn.dataset.title;
  $('#modalText').textContent=btn.dataset.text;
  $('#modalIcon').textContent=btn.querySelector('span').textContent;
  $('#modal').classList.remove('hidden');
}));
function closeModal(){$('#modal').classList.add('hidden')}
$('#closeModal').addEventListener('click',closeModal); $('#modalOk').addEventListener('click',closeModal);
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal()});
$('#refreshBtn').addEventListener('click',()=>{updateDemo(); $('#refreshBtn').animate([{transform:'rotate(0)'},{transform:'rotate(360deg)'}],{duration:450})});
