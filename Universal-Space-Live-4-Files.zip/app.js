document.addEventListener("DOMContentLoaded", () => {
  const sections = document.querySelectorAll(".section");
  const navButtons = document.querySelectorAll(".nav-btn");
  const sectionButtons = document.querySelectorAll("[data-section]");
  const menuButton = document.getElementById("menuButton");
  const exploreButton = document.getElementById("exploreButton");
  const aiButton = document.getElementById("aiButton");
  const aiMessage = document.getElementById("aiMessage");

  function showSection(id) {
    sections.forEach(section => section.classList.toggle("active", section.id === id));
    navButtons.forEach(button => button.classList.toggle("active", button.dataset.section === id));
    window.scrollTo({top: 0, behavior: "smooth"});
  }

  sectionButtons.forEach(button => {
    button.addEventListener("click", () => showSection(button.dataset.section));
  });

  if (exploreButton) exploreButton.addEventListener("click", () => showSection("space"));

  if (menuButton) {
    menuButton.addEventListener("click", () => {
      document.querySelector(".navigation").scrollIntoView({behavior:"smooth"});
    });
  }

  if (aiButton) {
    aiButton.addEventListener("click", () => {
      aiMessage.textContent = "🤖 Educational AI demo activated — live data integration will be added in the next stage.";
    });
  }

  // Simple animated satellite motion for the demo map.
  let angle = 0;
  const satellites = document.querySelectorAll(".satellite");
  setInterval(() => {
    angle = (angle + 1) % 360;
    satellites.forEach((satellite, index) => {
      satellite.style.transform = `rotate(${angle * (index ? -0.7 : 0.7)}deg)`;
    });
  }, 80);
});