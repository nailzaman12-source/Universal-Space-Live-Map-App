# Universal Space Live Map App

A mobile-friendly educational frontend for exploring Earth, space, weather, satellites, disasters and AI concepts.

## Files
- index.html — main application page
- style.css — responsive design
- app.js — navigation and interactive demo behavior

## Run
Open `index.html` in a browser. No backend or npm installation is required for this demo.

## Next stage
Public APIs can be connected later for real weather, satellite, astronomy and disaster data.
