document.addEventListener("DOMContentLoaded", () => {
  const sections = document.querySelectorAll(".section");
  const navButtons = document.querySelectorAll(".nav-btn");
  const sectionButtons = document.querySelectorAll("[data-section]");
  const navigation = document.getElementById("navigation");
  const menuButton = document.getElementById("menuButton");
  const exploreButton = document.getElementById("exploreButton");
  const aiButton = document.getElementById("aiButton");
  const aiMessage = document.getElementById("aiMessage");

  function showSection(id) {
    const target = document.getElementById(id);
    if (!target) return;

    sections.forEach(section => {
      section.classList.toggle("active", section.id === id);
    });

    navButtons.forEach(button => {
      button.classList.toggle("active", button.dataset.section === id);
    });

    navigation.classList.remove("open");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  sectionButtons.forEach(button => {
    button.addEventListener("click", () => showSection(button.dataset.section));
  });

  if (menuButton) {
    menuButton.addEventListener("click", () => {
      navigation.classList.toggle("open");
    });
  }

  if (exploreButton) {
    exploreButton.addEventListener("click", () => showSection("space"));
  }

  if (aiButton && aiMessage) {
    aiButton.addEventListener("click", () => {
      aiButton.disabled = true;
      aiButton.textContent = "AI Activated ✓";
      aiMessage.textContent =
        "Educational AI mode is ready. Public data integrations can be connected in the next development stage.";
      setTimeout(() => {
        aiButton.disabled = false;
        aiButton.textContent = "Activate Educational AI";
      }, 3000);
    });
  }

  console.log("Universal Space Live loaded successfully.");
});
