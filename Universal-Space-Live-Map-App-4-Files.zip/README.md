# Universal Space Live Map App

Mobile-friendly educational front-end.

Files: index.html, style.css, app.js.
