# Universal Space Live Map App

A mobile-friendly educational prototype for exploring Earth, space, weather, satellites, disasters and AI concepts.

## Files
- `index.html` — main application page
- `style.css` — complete responsive styling and animations
- `app.js` — navigation, mobile menu and AI demo interactions
- `README.md` — project information

## Run
Open `index.html` in a browser.

No backend or API key is required for this prototype.

## GitHub Pages
Upload the four files to the root of your repository and enable GitHub Pages from the repository settings. The entry file must be named `index.html`.
