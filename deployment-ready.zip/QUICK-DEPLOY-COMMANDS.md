# ⚡ QUICK DEPLOY COMMANDS

**Copy-Paste Ready Commands for Backend + Frontend Deployment**

---

## 🔴 BACKEND SETUP (Terminal 1)

### Extract & Install
```bash
unzip usl-backend-complete.zip
cd usl-backend
npm install
```

### Create .env
```bash
cat > .env << 'EOF'
PORT=5000
NODE_ENV=production
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/universal-space-live
JWT_SECRET=your_super_secret_key_make_it_long_and_random_123456789
JWT_EXPIRE=30d
NASA_API_KEY=DEMO_KEY
OPENWEATHER_API_KEY=your_key_here
CORS_ORIGIN=http://localhost:3000,http://localhost:5173,https://your-vercel-url.vercel.app
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your_16_char_app_password
FRONTEND_URL=http://localhost:3000
FRONTEND_URL_PROD=https://your-vercel-url.vercel.app
STRIPE_PUBLIC_KEY=pk_test_xxxx
STRIPE_SECRET_KEY=sk_test_xxxx
EOF
```

### Test Locally
```bash
npm run dev
# Visit: http://localhost:5000/api/health
```

### Push to GitHub
```bash
git add .
git commit -m "Backend setup"
git push origin main
```

### Deploy to Render
1. Go to https://render.com
2. Sign in with GitHub
3. Click "New" → "Web Service"
4. Select repo
5. Set:
   - Name: `usl-backend`
   - Build: `npm install`
   - Start: `npm start`
6. Add all .env variables
7. Deploy
8. Copy URL: `https://usl-backend-xxxx.onrender.com`

---

## 🔵 FRONTEND SETUP (Terminal 2)

### Extract & Install
```bash
unzip usl-app-improvements.zip
cd your-react-project

# Copy pages
cp usl-app-improvements/Login.jsx src/pages/
cp usl-app-improvements/Dashboard.jsx src/pages/
cp usl-app-improvements/Home.jsx src/pages/
cp usl-app-improvements/Signup.jsx src/pages/
cp usl-app-improvements/Achievements.jsx src/pages/
cp usl-app-improvements/AccountSettings.jsx src/pages/

# Copy components
cp usl-app-improvements/Navbar.jsx src/components/
cp usl-app-improvements/ProtectedRoute.jsx src/components/
cp usl-app-improvements/LoadingSpinner.jsx src/components/
cp usl-app-improvements/ErrorBoundary.jsx src/components/
cp usl-app-improvements/Toast.jsx src/components/
cp usl-app-improvements/AchievementCard.jsx src/components/
cp usl-app-improvements/ToastContext.jsx src/components/

# Copy hooks
cp usl-app-improvements/useAuth.js src/hooks/

# Copy App
cp usl-app-improvements/App.jsx src/

# Install deps
npm install
npm install react-router-dom lucide-react stripe @stripe/react-stripe-js @stripe/js
```

### Create .env.local
```bash
cat > .env.local << 'EOF'
VITE_API_URL=http://localhost:5000/api
VITE_STRIPE_PUBLIC_KEY=pk_test_xxxx
EOF
```

### Create .env.production
```bash
cat > .env.production << 'EOF'
VITE_API_URL=https://usl-backend-xxxx.onrender.com/api
VITE_STRIPE_PUBLIC_KEY=pk_test_xxxx
EOF
```

### Test Locally
```bash
npm run dev
# Visit: http://localhost:5173
```

### Build for Production
```bash
npm run build
# Creates dist/ folder
```

### Push to GitHub
```bash
git add .
git commit -m "Frontend setup"
git push origin main
```

### Deploy to Vercel
1. Go to https://vercel.com
2. Sign in with GitHub
3. Click "New Project"
4. Select your repo
5. Set:
   - Framework: Vite
   - Build: `npm run build`
   - Output: `dist`
6. Add env vars:
   - `VITE_API_URL=https://usl-backend-xxxx.onrender.com/api`
   - `VITE_STRIPE_PUBLIC_KEY=pk_test_xxx`
7. Deploy
8. Copy URL: `https://your-project.vercel.app`

---

## 🔗 CONNECT THEM

### Update Backend .env
```bash
CORS_ORIGIN=https://your-project.vercel.app
FRONTEND_URL_PROD=https://your-project.vercel.app
```

Redeploy backend on Render.

### Update Frontend .env.production
```bash
VITE_API_URL=https://usl-backend-xxxx.onrender.com/api
```

Redeploy frontend on Vercel.

---

## ✅ TEST CONNECTION

### Backend Health Check
```bash
curl https://usl-backend-xxxx.onrender.com/api/health
# Should return: { "status": "ok" }
```

### Frontend Test
```
Visit: https://your-project.vercel.app/login
Open DevTools → Network tab
Try to sign up
Should see API calls to backend
```

---

## 📊 YOUR URLS

```
Frontend:  https://your-project.vercel.app
Backend:   https://usl-backend-xxxx.onrender.com
API:       https://usl-backend-xxxx.onrender.com/api

Test URLs:
- Home:    https://your-project.vercel.app/
- Login:   https://your-project.vercel.app/login
- Health:  https://usl-backend-xxxx.onrender.com/api/health
```

---

## 🚨 IF SOMETHING BREAKS

### Check Backend Logs
```
Render.com → Dashboard → Your Service → Logs
```

### Check Frontend Logs
```
Vercel.com → Dashboard → Your Project → Deployments → Logs
```

### Check Browser Errors
```
F12 → Console → Look for red errors
F12 → Network → Look for failed requests
```

### Common Fixes
```bash
# Clear cache & rebuild
rm -rf node_modules dist
npm install
npm run build

# Reset env
cat > .env << 'EOF'
# Paste new values
EOF

# Redeploy
git add .
git commit -m "Fix: update env"
git push
```

---

## 🎉 SUCCESS INDICATORS

✅ Backend URL loads without error
✅ Frontend URL loads homepage
✅ Can click through pages
✅ API health check returns ok
✅ No CORS errors in console
✅ Can fill login form
✅ Network tab shows API calls
✅ Real data showing in dashboard

---

## 🚀 DEPLOYMENT SUMMARY

```
Total Time: ~2 hours
- Backend Setup: 30 min
- Frontend Setup: 30 min
- Deployment: 45 min
- Testing: 15 min

Result:
✅ Live Frontend: vercel.app
✅ Live Backend: onrender.com
✅ Connected & Working
✅ Production Ready
```

---

**Ready? Start with Backend Commands in Terminal 1!**

**Follow each section step by step!**

**Questions? Check logs first!**

**Good luck! 🚀🌌**
