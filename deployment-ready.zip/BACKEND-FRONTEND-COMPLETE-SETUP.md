# 🚀 Complete Backend + Frontend Setup & Deployment Guide

**For: Noor Zaman | GitHub: nailzaman12-source**

---

## ⚡ 3-Step Setup Process

1. **Backend Setup (Render.com)** - 30 minutes
2. **Frontend Setup (Vercel)** - 30 minutes  
3. **Connect Karna** - 15 minutes

---

## 📍 STEP 1: BACKEND SETUP (Render.com)

### 1.1 Extract Backend Files

```bash
unzip usl-backend-complete.zip
cd usl-backend
```

### 1.2 Install Dependencies

```bash
npm install
```

### 1.3 Setup .env File

Create `.env` file in root:

```env
# Server
PORT=5000
NODE_ENV=production
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/universal-space-live

# JWT
JWT_SECRET=your_super_secret_key_here_make_it_long_and_random
JWT_EXPIRE=30d

# NASA API (Free)
NASA_API_KEY=DEMO_KEY

# OpenWeather API (Free)
OPENWEATHER_API_KEY=your_openweather_key

# CORS
CORS_ORIGIN=http://localhost:3000,http://localhost:5173,https://your-vercel-domain.vercel.app

# Email (Gmail)
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your_16_char_app_password

# Frontend URL
FRONTEND_URL=http://localhost:3000
FRONTEND_URL_PROD=https://your-vercel-domain.vercel.app

# Stripe (Optional)
STRIPE_PUBLIC_KEY=pk_test_xxxx
STRIPE_SECRET_KEY=sk_test_xxxx
```

### 1.4 Get API Keys

**NASA API (FREE):**
1. Visit: https://api.nasa.gov
2. Fill form
3. Copy key to EMAIL
4. Add to `.env` as `NASA_API_KEY`

**OpenWeather API (FREE):**
1. Visit: https://openweathermap.org/api
2. Sign up
3. Go to API keys
4. Copy key
5. Add to `.env`

**Gmail App Password:**
1. myaccount.google.com
2. Security
3. Enable 2-Factor Auth
4. App passwords
5. Select "Mail"
6. Copy 16-char password
7. Add to `.env`

### 1.5 Test Backend Locally

```bash
npm run dev
```

Output should show:
```
✓ Server running on port 5000
✓ Database connected
✓ API ready
```

Visit: http://localhost:5000/api/health
Should see: `{ "status": "ok" }`

### 1.6 Push to GitHub

```bash
git add .
git commit -m "Backend setup complete"
git push origin main
```

### 1.7 Deploy to Render.com

**Option A: Auto-Deploy (Recommended)**

1. Visit: https://render.com
2. Sign in with GitHub
3. Click "New" → "Web Service"
4. Connect GitHub repo
5. Fill form:
   - **Name:** usl-backend
   - **Branch:** main
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Environment:** Node.js
   - **Instance Type:** Free (ok for testing)

6. Add Environment Variables:
   ```
   MONGODB_URI=your_atlas_uri
   JWT_SECRET=your_secret
   NASA_API_KEY=your_key
   OPENWEATHER_API_KEY=your_key
   EMAIL_USER=your_email
   EMAIL_PASSWORD=app_password
   FRONTEND_URL_PROD=your_vercel_domain
   CORS_ORIGIN=your_vercel_domain
   ```

7. Click "Create Web Service"
8. Wait 5-10 minutes for deployment
9. Copy your URL: `https://usl-backend.onrender.com`

**Option B: Manual Deploy**

```bash
git push heroku main
# or use Render CLI
render deploy
```

### 1.8 Verify Backend is Live

Visit: `https://your-backend-url.onrender.com/api/health`

Should see: `{ "status": "ok" }`

---

## 📱 STEP 2: FRONTEND SETUP (Vercel)

### 2.1 Extract Frontend Files

```bash
unzip usl-app-improvements.zip
cd usl-frontend
```

### 2.2 Copy Files to Your Project

```bash
# Pages
cp Login.jsx Dashboard.jsx Home.jsx Signup.jsx Achievements.jsx src/pages/

# Components
cp Navbar.jsx ProtectedRoute.jsx LoadingSpinner.jsx ErrorBoundary.jsx Toast.jsx AchievementCard.jsx ToastContext.jsx src/components/

# Hooks
cp useAuth.js src/hooks/

# App
cp App.jsx src/
```

### 2.3 Install Dependencies

```bash
npm install
npm install react-router-dom lucide-react
npm install stripe @stripe/react-stripe-js @stripe/js
```

### 2.4 Setup .env.local

Create `.env.local` in project root:

```env
VITE_API_URL=http://localhost:5000/api
VITE_STRIPE_PUBLIC_KEY=pk_test_xxxx
```

For production (.env.production):
```env
VITE_API_URL=https://your-backend-url.onrender.com/api
VITE_STRIPE_PUBLIC_KEY=pk_test_xxxx
```

### 2.5 Test Locally

```bash
npm run dev
```

Should show:
```
✓ Local: http://localhost:5173
```

Test in browser:
- http://localhost:5173/
- http://localhost:5173/login
- http://localhost:5173/dashboard

### 2.6 Build for Production

```bash
npm run build
```

This creates `dist/` folder with production files.

### 2.7 Push to GitHub

```bash
git add .
git commit -m "Frontend setup complete"
git push origin main
```

### 2.8 Deploy to Vercel

**Option A: Using GitHub (EASIEST)**

1. Visit: https://vercel.com
2. Sign in with GitHub
3. Click "New Project"
4. Select your repository
5. Fill form:
   - **Project Name:** universal-space-live
   - **Framework:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`

6. Add Environment Variables:
   ```
   VITE_API_URL=https://your-backend-url.onrender.com/api
   VITE_STRIPE_PUBLIC_KEY=pk_test_xxx
   ```

7. Click "Deploy"
8. Wait 2-5 minutes
9. Get your domain: `https://your-project.vercel.app`

**Option B: Using Vercel CLI**

```bash
npm install -g vercel
vercel
# Follow prompts
```

### 2.9 Verify Frontend is Live

Visit: `https://your-project.vercel.app`

Should see homepage with "Explore Earth. Discover Space."

---

## 🔗 STEP 3: CONNECT BACKEND + FRONTEND

### 3.1 Update Backend CORS

In backend `.env`, add frontend URL:

```env
CORS_ORIGIN=https://your-vercel-domain.vercel.app
```

Redeploy backend.

### 3.2 Update Frontend API URL

In frontend `.env.production`, set:

```env
VITE_API_URL=https://your-backend-url.onrender.com/api
```

Redeploy frontend.

### 3.3 Test Connection

1. Visit frontend: https://your-vercel-domain.vercel.app
2. Click "Sign Up"
3. Try to create account
4. Should see API response in browser console

**If Error:** Check browser console → Network tab → API calls

---

## ✅ VERIFICATION CHECKLIST

### Backend Working?
- [ ] Backend URL loads health check
- [ ] No CORS errors in console
- [ ] API endpoints responding
- [ ] Database connected
- [ ] Email working

### Frontend Working?
- [ ] Home page loads
- [ ] Navigation works
- [ ] Can go to login
- [ ] Can go to signup
- [ ] Responsive on mobile

### Connected?
- [ ] Sign up makes API call
- [ ] Login makes API call
- [ ] Dashboard loads data
- [ ] No console errors
- [ ] Data displaying

---

## 🐛 TROUBLESHOOTING

### Error: "Cannot reach API"

**Solution:**
```
1. Check backend URL in frontend .env
2. Verify backend is running
3. Check CORS settings
4. Restart both servers
```

### Error: "CORS error"

**Solution:**
```
1. Add frontend URL to backend CORS_ORIGIN
2. Redeploy backend
3. Clear browser cache
4. Test again
```

### Error: "Database connection failed"

**Solution:**
```
1. Check MONGODB_URI in .env
2. Verify IP is whitelisted (MongoDB Atlas)
3. Test connection string
4. Restart backend
```

### Error: "Stripe not working"

**Solution:**
```
1. Check API keys are correct
2. Use test keys (pk_test_, sk_test_)
3. Wait for Stripe account approval
4. Restart frontend
```

### Error: "Email not sending"

**Solution:**
```
1. Enable 2-Factor Auth in Gmail
2. Generate app password (16 chars)
3. Use app password in .env
4. Restart backend
5. Test email endpoint
```

---

## 📊 YOUR DEPLOYMENT URLS

Once deployed, you'll have:

```
Frontend:  https://your-frontend.vercel.app
Backend:   https://your-backend.onrender.com
API Base:  https://your-backend.onrender.com/api

Test URLs:
- Home:       https://your-frontend.vercel.app/
- Login:      https://your-frontend.vercel.app/login
- API Health: https://your-backend.onrender.com/api/health
```

---

## 🚀 DEPLOYMENT COMPLETE CHECKLIST

### Before Going Live
- [ ] All dependencies installed
- [ ] .env files configured
- [ ] API keys obtained
- [ ] Database connected
- [ ] Email working
- [ ] CORS configured
- [ ] Built and tested locally
- [ ] Pushed to GitHub
- [ ] Backend deployed to Render
- [ ] Frontend deployed to Vercel
- [ ] Environment variables set
- [ ] Connected and tested

### Production Checklist
- [ ] HTTPS enabled (automatic on Vercel/Render)
- [ ] Environment variables secure
- [ ] API keys in production mode
- [ ] Database backups enabled
- [ ] Error logging setup
- [ ] Monitoring enabled
- [ ] Rate limiting configured
- [ ] Security headers set

---

## 🔐 SECURITY BEST PRACTICES

✅ Never commit .env file
✅ Use environment variables for secrets
✅ Use production API keys only on production
✅ Enable HTTPS (automatic)
✅ Whitelist IP addresses
✅ Monitor API usage
✅ Regular backups
✅ Update dependencies

---

## 📈 MONITORING & LOGS

### View Backend Logs
```
Render Dashboard → Your Service → Logs
```

### View Frontend Logs
```
Vercel Dashboard → Your Project → Deployments → Logs
```

### Monitor Database
```
MongoDB Atlas → Clusters → Activity
```

---

## 🎯 NEXT STEPS AFTER DEPLOYMENT

1. **Share Links**
   - Send frontend URL to users
   - Keep backend URL private

2. **Monitor Usage**
   - Watch API calls
   - Monitor error rates
   - Check database size

3. **Add Features**
   - Payment system
   - More pages
   - More gamification

4. **Marketing**
   - Share on social media
   - Get users
   - Gather feedback

---

## 💡 QUICK REFERENCE

**Backend Deployed?**
```bash
curl https://your-backend.onrender.com/api/health
```

**Frontend Deployed?**
```
Visit https://your-frontend.vercel.app
```

**Connected?**
```bash
Check Network tab in browser DevTools
```

---

## 🎉 CONGRATULATIONS!

You now have:

✅ Backend running on Render.com
✅ Frontend running on Vercel
✅ Database connected (MongoDB Atlas)
✅ APIs integrated
✅ Real-time data flowing
✅ Production ready app
✅ Professional deployment
✅ Scalable architecture

---

## 📞 SUPPORT

### Need Help?
1. Check logs (Render/Vercel)
2. Check browser console (DevTools)
3. Check network requests
4. Read documentation files
5. Check GitHub issues

### Quick Fixes
- **Page not loading?** → Check .env
- **API not working?** → Check CORS & backend
- **Data not showing?** → Check API endpoints
- **Email not working?** → Check Gmail settings
- **Payment not working?** → Check Stripe keys

---

**🎊 YAY! Aapka app live hai! 🚀🌌**

**Frontend:** https://your-frontend.vercel.app
**Backend:** https://your-backend.onrender.com

**Share with friends! Get users! Grow your platform!**

**Built for Universal Space Live - Professional Deployment! 💳🌟**
