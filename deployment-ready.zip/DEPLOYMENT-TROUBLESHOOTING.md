# 🔧 Deployment Troubleshooting Guide

**Common Issues & Solutions**

---

## 🔴 BACKEND ISSUES

### Issue 1: "Port 5000 already in use"

**Error:**
```
Error: listen EADDRINUSE: address already in use :::5000
```

**Solution:**
```bash
# Kill process on port 5000
# On Mac/Linux:
lsof -ti:5000 | xargs kill -9

# On Windows:
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Change port in .env
PORT=5001
```

---

### Issue 2: "Cannot connect to MongoDB"

**Error:**
```
MongooseError: Cannot connect to MongoDB
```

**Solutions:**
```
1. Check MONGODB_URI in .env is correct
2. Make sure database name is correct
3. Check username/password (no special chars)
4. Whitelist your IP in MongoDB Atlas
5. Verify connection string format
6. Test locally first
```

**Connection String Format:**
```
mongodb+srv://username:password@cluster.mongodb.net/database-name?retryWrites=true&w=majority
```

**Fix:**
```bash
# Get connection string from MongoDB Atlas
1. MongoDB.com → Cluster → Connect
2. Choose "Connect your application"
3. Copy connection string
4. Replace username & password
5. Add to .env as MONGODB_URI
```

---

### Issue 3: "API returns 404 errors"

**Error:**
```
GET /api/nasa/apod → 404 Not Found
```

**Solution:**
```bash
# Check routes are registered in server.js
# File: server.js

const nasaRoutes = require('./routes/nasa');
const weatherRoutes = require('./routes/weather');
const authRoutes = require('./routes/auth');

app.use('/api/nasa', nasaRoutes);
app.use('/api/weather', weatherRoutes);
app.use('/api/auth', authRoutes);
```

**Verify:**
```bash
# Test endpoint locally
curl http://localhost:5000/api/health

# Should return:
{ "status": "ok" }
```

---

### Issue 4: "CORS error in browser"

**Error:**
```
Access to XMLHttpRequest blocked by CORS policy
```

**Solution:**
```bash
# Update .env
CORS_ORIGIN=http://localhost:5173,https://your-frontend.vercel.app

# Restart backend
npm run dev

# Check server.js has:
const cors = require('cors');
app.use(cors({
  origin: process.env.CORS_ORIGIN.split(','),
  credentials: true
}));
```

---

### Issue 5: "NASA API key not working"

**Error:**
```
Error: 403 Forbidden from NASA API
```

**Solution:**
```bash
# Get new key
1. Visit https://api.nasa.gov
2. Fill form with your email
3. Key sent to email
4. Copy key to .env
NASA_API_KEY=your_actual_key (not DEMO_KEY)

# Restart backend
npm run dev
```

---

### Issue 6: "Email not sending"

**Error:**
```
Error: Bad credentials for Gmail
```

**Solution:**
```bash
# Step 1: Enable 2-Factor Auth
1. myaccount.google.com
2. Security
3. 2-Step Verification → Enable

# Step 2: Get App Password
1. myaccount.google.com → Security
2. App passwords
3. Select "Mail" and "Windows Computer"
4. Generate password (16 characters)
5. Copy exactly as shown

# Step 3: Update .env
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=xxxx xxxx xxxx xxxx (the 16-char one)

# Step 4: Restart
npm run dev
```

---

### Issue 7: "500 Internal Server Error"

**Error:**
```
Error: 500 Internal Server Error
```

**Solution:**
```bash
# 1. Check backend logs
npm run dev
# Look for red error messages

# 2. Check .env has all required variables
PORT=5000
MONGODB_URI=xxx
JWT_SECRET=xxx
NASA_API_KEY=xxx
EMAIL_USER=xxx
EMAIL_PASSWORD=xxx

# 3. Restart backend
npm run dev

# 4. Test endpoint with Postman or curl
curl http://localhost:5000/api/health
```

---

## 🔵 FRONTEND ISSUES

### Issue 1: "Cannot find module 'react-router-dom'"

**Error:**
```
Error: Cannot find module 'react-router-dom'
```

**Solution:**
```bash
npm install react-router-dom
npm install lucide-react
npm run dev
```

---

### Issue 2: "VITE_API_URL is undefined"

**Error:**
```
Error: Cannot read property 'VITE_API_URL' of undefined
```

**Solution:**
```bash
# 1. Create .env.local in project root
cat > .env.local << 'EOF'
VITE_API_URL=http://localhost:5000/api
VITE_STRIPE_PUBLIC_KEY=pk_test_xxx
EOF

# 2. Restart dev server
npm run dev

# 3. Verify in code
console.log(import.meta.env.VITE_API_URL)
// Should log your API URL
```

---

### Issue 3: "Page shows 404"

**Error:**
```
Cannot GET /dashboard
```

**Solution:**
```bash
# Check App.jsx has the route
// App.jsx
<Routes>
  <Route path="/" element={<Home />} />
  <Route path="/dashboard" element={<Dashboard />} />
  <Route path="/login" element={<Login />} />
  ...
</Routes>

# Verify components exist in src/pages/
# Then restart
npm run dev
```

---

### Issue 4: "Build fails"

**Error:**
```
npm run build → Fails with errors
```

**Solution:**
```bash
# 1. Clear cache
rm -rf node_modules dist
npm install

# 2. Fix any import errors
# Check console output for specific errors
# Usually missing imports or files

# 3. Try building again
npm run build

# 4. If still fails, check:
# - All components imported correctly
# - All files exist
# - No syntax errors
# - No missing dependencies
```

---

### Issue 5: "Styles not applied"

**Error:**
```
Page loads but no colors/styling
```

**Solution:**
```bash
# Check Tailwind is installed
npm install -D tailwindcss postcss autoprefixer

# Check tailwind.config.js exists
// tailwind.config.js
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: { extend: {} },
  plugins: [],
}

# Check index.css has Tailwind imports
/* index.css */
@tailwind base;
@tailwind components;
@tailwind utilities;

# Restart
npm run dev
```

---

### Issue 6: "API not responding"

**Error:**
```
GET /api/health → Network error
```

**Solution:**
```bash
# 1. Check backend is running
# Terminal 1: npm run dev (backend)

# 2. Check frontend API URL
// .env.local
VITE_API_URL=http://localhost:5000/api

# 3. Test directly
curl http://localhost:5000/api/health
// Should return { "status": "ok" }

# 4. Check Network tab in DevTools
// F12 → Network → Make API call
// Look for CORS errors or timeouts
```

---

### Issue 7: "Login doesn't work"

**Error:**
```
Click login → Nothing happens
```

**Solution:**
```bash
# 1. Open DevTools
F12 → Console

# 2. Check for errors (red messages)

# 3. Check Network tab
F12 → Network → Click login → Look for API request

# 4. Common issues:
✓ API URL wrong in .env
✓ Backend not running
✓ CORS not configured
✓ Database not connected
✓ Email validation failing

# 5. Fix:
- Verify .env.local
- Check backend logs
- Restart both servers
```

---

## 🌐 DEPLOYMENT ISSUES

### Issue 1: "Render deployment fails"

**Error:**
```
Build failed on Render
```

**Solution:**
```bash
# 1. Check build command
# Should be: npm install

# 2. Check start command
# Should be: npm start

# 3. Check .env variables in Render dashboard
# Make sure ALL required vars are set

# 4. Check package.json has correct scripts
{
  "scripts": {
    "dev": "node server.js",
    "start": "node server.js"
  }
}

# 5. Redeploy
# Render → Deployments → Click latest → Redeploy
```

---

### Issue 2: "Vercel deployment fails"

**Error:**
```
Build failed on Vercel
```

**Solution:**
```bash
# 1. Check build command
# Should be: npm run build

# 2. Check output directory
# Should be: dist

# 3. Check .env variables
# Make sure VITE_API_URL is set

# 4. Check vercel.json if exists
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist"
}

# 5. Redeploy
# Vercel → Deployments → Click... → Redeploy
```

---

### Issue 3: "Frontend can't reach backend"

**Error:**
```
Frontend loads but API calls fail
CORS error in console
```

**Solution:**
```bash
# 1. Check backend CORS settings
// .env (Backend)
CORS_ORIGIN=https://your-frontend.vercel.app

# 2. Check frontend API URL
// .env.production (Frontend)
VITE_API_URL=https://usl-backend-xxx.onrender.com/api

# 3. Verify both are deployed
# Render dashboard → Check backend is running
# Vercel dashboard → Check frontend is running

# 4. Redeploy both
# Backend → Render → Redeploy
# Frontend → Vercel → Redeploy
```

---

## 🧪 QUICK TESTS

### Test Backend Locally
```bash
# Start backend
npm run dev

# In another terminal:
# Test health
curl http://localhost:5000/api/health

# Should return:
{ "status": "ok" }
```

### Test Frontend Locally
```bash
# In project directory
npm run dev

# Open browser
http://localhost:5173

# Test:
✓ Can access home page
✓ Can click login
✓ Can access dashboard
✓ DevTools shows no errors
```

### Test Connection
```bash
# Make sure both running:
# Terminal 1: npm run dev (backend)
# Terminal 2: npm run dev (frontend)

# In frontend browser:
# F12 → Network tab
# Go to /login
# Try to sign up
# Look for API call to backend
# Should see 200 response, not 404 or CORS error
```

---

## 📊 DEBUGGING CHECKLIST

- [ ] Backend running? → Terminal shows "listening on port"
- [ ] Frontend running? → Terminal shows "Local: http://localhost:5173"
- [ ] .env files exist? → Check both directories
- [ ] All env vars set? → Compare with examples
- [ ] Dependencies installed? → `node_modules` folder exists
- [ ] No syntax errors? → Check console for red errors
- [ ] API responding? → `curl http://localhost:5000/api/health`
- [ ] CORS configured? → No CORS errors in DevTools
- [ ] Database connected? → Check Render/Backend logs

---

## 🚨 WHEN ALL ELSE FAILS

### Step 1: Clear Everything
```bash
# Backend
rm -rf node_modules
npm install
npm run dev

# Frontend (in new terminal)
rm -rf node_modules
npm install
npm run dev
```

### Step 2: Check Each Part
```bash
# Can I reach backend?
curl http://localhost:5000/api/health

# Can I reach frontend?
Visit http://localhost:5173

# Are they connected?
F12 → Network → Try API call
```

### Step 3: Verify .env Files
```bash
# Backend .env
cat .env
# Check MONGODB_URI, NASA_API_KEY, etc.

# Frontend .env.local
cat .env.local
# Check VITE_API_URL
```

### Step 4: Read Logs
```bash
# Backend logs
# Terminal 1: npm run dev
# Look for errors in red

# Frontend logs
# Terminal 2: npm run dev
# Look for errors in console

# Browser logs
# F12 → Console
# Look for red error messages
```

### Step 5: Ask for Help
```
Provide:
1. Error message (exact text)
2. Screenshot of error
3. .env file (without secrets)
4. Terminal output
5. Browser console output

Post on:
- GitHub Issues
- Stack Overflow
- Discord server
```

---

## ✅ SUCCESS SIGNS

- ✅ Backend terminal: "listening on port 5000"
- ✅ Frontend terminal: "Local: http://localhost:5173"
- ✅ Browser: Homepage loads with styling
- ✅ Navigation: Can click between pages
- ✅ Console: No red errors
- ✅ Network: API calls showing 200 status
- ✅ Data: Real data displaying on dashboard

---

**Still stuck? Read the guide files!**

**Check logs first!**

**Test each part separately!**

**Good luck! 🚀**
