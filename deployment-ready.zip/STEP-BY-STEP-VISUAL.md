# 📍 Step-by-Step Visual Guide

---

## 🎯 PHASE 1: BACKEND DEPLOYMENT (30 mins)

### Step 1: Extract Backend
```
📦 usl-backend-complete.zip
    ↓ unzip
📁 usl-backend/
    ├── server.js
    ├── package.json
    ├── models/
    ├── routes/
    └── .env (CREATE THIS)
```

**Command:**
```bash
unzip usl-backend-complete.zip
cd usl-backend
```

---

### Step 2: Install Packages
```
📁 usl-backend/
    ↓ npm install
✅ node_modules/ (created)
```

**Command:**
```bash
npm install
```

---

### Step 3: Create .env File
```
📁 usl-backend/
    ├── server.js
    ├── package.json
    ├── .env ← CREATE WITH KEYS
    │   ├── MONGODB_URI
    │   ├── NASA_API_KEY
    │   ├── EMAIL settings
    │   └── ... more
    └── ...
```

**Get Keys From:**
- 🔑 NASA: https://api.nasa.gov
- 🌤️ Weather: https://openweathermap.org
- 📧 Gmail: myaccount.google.com → App passwords

---

### Step 4: Test Locally
```
npm run dev
    ↓
✅ Server running on port 5000
✅ Database connected
✅ API ready
```

Visit: http://localhost:5000/api/health

---

### Step 5: Push to GitHub
```
📁 usl-backend/ (with .env)
    ↓ git add, commit, push
🐙 GitHub
    └── nailzaman12-source/Universal-Space-Live-Map-App
        └── branch: main
```

**Commands:**
```bash
git add .
git commit -m "Backend setup"
git push origin main
```

---

### Step 6: Deploy to Render
```
🐙 GitHub (your repo)
    ↓ connect
🟦 Render.com
    ├── Select repo
    ├── Add env vars
    ├── Deploy
    └── ✅ Backend LIVE!
        https://usl-backend-xxx.onrender.com
```

**Steps:**
1. render.com → Sign in with GitHub
2. New → Web Service
3. Select repo
4. Fill form:
   - Name: `usl-backend`
   - Build: `npm install`
   - Start: `npm start`
5. Add env variables
6. Deploy → Wait 5-10 mins

---

### ✅ Backend Ready!
```
Backend URL: https://usl-backend-xxx.onrender.com
Health Check: https://usl-backend-xxx.onrender.com/api/health
```

---

## 🎯 PHASE 2: FRONTEND DEPLOYMENT (30 mins)

### Step 1: Extract Frontend
```
📦 usl-app-improvements.zip
    ↓ unzip
📁 usl-app-improvements/
    ├── Login.jsx
    ├── Dashboard.jsx
    ├── Navbar.jsx
    ├── App.jsx
    ├── README.md
    └── ... more files
```

**Command:**
```bash
unzip usl-app-improvements.zip
```

---

### Step 2: Copy Files to Project
```
📁 usl-app-improvements/
    ├── Login.jsx → 📁 src/pages/
    ├── Dashboard.jsx → 📁 src/pages/
    ├── Navbar.jsx → 📁 src/components/
    ├── App.jsx → 📁 src/
    └── ...

Your Project Structure Ready ✅
```

---

### Step 3: Install Dependencies
```
npm install
    ↓
npm install react-router-dom lucide-react
    ↓
npm install stripe @stripe/react-stripe-js @stripe/js
    ↓
✅ All packages installed
```

---

### Step 4: Create Environment Files
```
📁 your-project/
    ├── .env.local (for development)
    │   VITE_API_URL=http://localhost:5000/api
    │
    └── .env.production (for production)
        VITE_API_URL=https://usl-backend-xxx.onrender.com/api
```

---

### Step 5: Test Locally
```
npm run dev
    ↓
✅ Local: http://localhost:5173
    ✓ Home page works
    ✓ Login page works
    ✓ Navigation works
```

---

### Step 6: Build for Production
```
npm run build
    ↓
📁 dist/ (created)
    ├── index.html
    ├── assets/
    │   ├── main.js
    │   └── style.css
    └── ... more
```

---

### Step 7: Push to GitHub
```
📁 your-project/ (with files copied)
    ↓ git add, commit, push
🐙 GitHub
    └── nailzaman12-source/Universal-Space-Live-Map-App
        └── branch: main
```

**Commands:**
```bash
git add .
git commit -m "Frontend setup"
git push origin main
```

---

### Step 8: Deploy to Vercel
```
🐙 GitHub (your repo)
    ↓ connect
🔵 Vercel
    ├── Select repo
    ├── Set framework: Vite
    ├── Add env vars
    ├── Deploy
    └── ✅ Frontend LIVE!
        https://your-project.vercel.app
```

**Steps:**
1. vercel.com → Sign in with GitHub
2. New Project
3. Select repo
4. Framework: Vite
5. Add env var: `VITE_API_URL`
6. Deploy → Wait 2-5 mins

---

### ✅ Frontend Ready!
```
Frontend URL: https://your-project.vercel.app
Home: https://your-project.vercel.app/
Login: https://your-project.vercel.app/login
```

---

## 🎯 PHASE 3: CONNECT THEM (15 mins)

### Step 1: Update Backend CORS
```
🔴 Backend (.env)
    CORS_ORIGIN=https://your-project.vercel.app
```

Redeploy on Render.

---

### Step 2: Update Frontend API URL
```
🔵 Frontend (.env.production)
    VITE_API_URL=https://usl-backend-xxx.onrender.com/api
```

Redeploy on Vercel.

---

### Step 3: Test Connection
```
🔵 Frontend → Click "Sign Up"
    ↓
📡 API Call
    ↓
🔴 Backend → Process request
    ↓
✅ Response → Show in Frontend
```

**Check:** Browser Console → Network tab → Look for API calls

---

## 🎉 FINAL SETUP

```
🔴 Backend
┌─────────────────────────────────┐
│ https://usl-backend-xxx.onrender.com
│ - Running on Render.com
│ - Connected to MongoDB
│ - 40+ API endpoints
└─────────────────────────────────┘
         ↑
         │ API Calls
         ↓
┌─────────────────────────────────┐
│ https://your-project.vercel.app
│ 🔵 Frontend
│ - Running on Vercel
│ - React + Router
│ - Real-time data
└─────────────────────────────────┘
```

---

## ✅ VERIFICATION CHECKLIST

### Backend
- [ ] Health check responds: http://backend/api/health
- [ ] No errors in Render logs
- [ ] Database connected
- [ ] API endpoints working

### Frontend
- [ ] Home page loads
- [ ] Navigation works
- [ ] Can click all links
- [ ] Responsive on mobile

### Connected
- [ ] No CORS errors
- [ ] Sign up makes API call
- [ ] Real data showing
- [ ] Network tab shows requests

---

## 🚀 YOUR LIVE URLS

```
Frontend:  https://your-project.vercel.app
Backend:   https://usl-backend-xxx.onrender.com
API:       https://usl-backend-xxx.onrender.com/api
```

**Share frontend URL with users!**
**Keep backend URL for yourself!**

---

## 🎊 DEPLOYMENT COMPLETE!

```
✅ Backend running on Render
✅ Frontend running on Vercel
✅ Connected and working
✅ Real-time data flowing
✅ Production ready
✅ Scalable architecture
✅ Professional deployment
✅ Ready for users!
```

---

## 📋 QUICK REFERENCE

| Task | Command |
|------|---------|
| Backend setup | `unzip && npm install` |
| Backend test | `npm run dev` |
| Frontend setup | Copy files → `npm install` |
| Frontend test | `npm run dev` |
| Build frontend | `npm run build` |
| Push to GitHub | `git push origin main` |

---

**🎯 Follow each phase in order!**

**❓ Stuck? Check logs!**

**✅ Done? Share your link!**

**🚀 Good luck! 🌌**
