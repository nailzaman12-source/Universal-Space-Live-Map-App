const events=[
  {icon:"☀️",title:"Solar activity",text:"Quiet conditions in this demo feed."},
  {icon:"🛰️",title:"Satellite observation",text:"12 example objects available for tracking."},
  {icon:"🌍",title:"Earth observation",text:"Global observation layer is ready for API integration."}
];

const eventsBox=document.getElementById("events");
eventsBox.innerHTML=events.map(e=>`<div class="event"><b>${e.icon} ${e.title}</b><span class="muted">${e.text}</span></div>`).join("");

function refresh(){
  const temp=24+Math.floor(Math.random()*9);
  document.getElementById("weather").textContent=temp+"°C";
  document.getElementById("bigTemp").textContent=temp+"°";
  document.getElementById("satCount").textContent=10+Math.floor(Math.random()*8);
  const solar=["Quiet","Low","Moderate"][Math.floor(Math.random()*3)];
  document.getElementById("solar").textContent=solar;
}
document.getElementById("refreshBtn").addEventListener("click",refresh);

document.getElementById("themeBtn").addEventListener("click",()=>{
  document.body.classList.toggle("light");
  document.getElementById("themeBtn").textContent=document.body.classList.contains("light")?"☀":"☾";
});

const answers=[
  "A solar flare is a sudden release of energy from the Sun. Strong flares can affect radio communication and space weather.",
  "Satellites are spacecraft placed in orbit to observe Earth, communicate, navigate, or study space.",
  "Space weather describes changing conditions on the Sun and in near-Earth space, including solar wind and solar flares."
];
document.getElementById("askBtn").addEventListener("click",()=>{
  const q=document.getElementById("question").value.trim();
  document.getElementById("answer").textContent=q ? answers[Math.floor(Math.random()*answers.length)] : "Please enter an educational question.";
});
document.getElementById("question").addEventListener("keydown",e=>{if(e.key==="Enter")document.getElementById("askBtn").click()});
