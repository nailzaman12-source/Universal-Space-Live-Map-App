# Universal Space Live — Starter

This is a simple front-end prototype for **Universal Space Live**.

## Included
- Responsive Earth/space dashboard
- Universal map visual demo
- Space events panel
- Weather demo
- Satellite counter
- Educational AI assistant prototype
- Light/dark theme
- No API keys required

## Run
Open `index.html` in a browser.

## GitHub mobile upload
1. Open your repository.
2. Tap **Add file / Upload files**.
3. Upload `index.html`, `style.css`, `app.js`, and `README.md`.
4. Commit the changes.
5. Open `index.html` to verify the files are present.

## Next step
Connect real public APIs for weather, NASA/open space data, satellite positions and maps. Keep the application educational and non-weaponized.
