import express from "express";
import cors from "cors";

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get("/", (_req, res) => {
  res.json({ name: "Universal Space Live API", status: "online", version: "1.0.0" });
});

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "usl-api", timestamp: new Date().toISOString() });
});

app.get("/api/earth", (_req, res) => {
  res.json({ status: "ok", message: "Earth data endpoint ready for public-data integration." });
});

app.get("/api/space", (_req, res) => {
  res.json({ status: "ok", message: "Space data endpoint ready for astronomy integration." });
});

app.get("/api/weather", (_req, res) => {
  res.json({ status: "ok", message: "Weather endpoint ready for a public weather provider." });
});

app.get("/api/satellites", (_req, res) => {
  res.json({ status: "ok", message: "Satellite endpoint ready for public orbital data." });
});

app.get("/api/disasters", (_req, res) => {
  res.json({ status: "ok", message: "Disaster endpoint ready for public event feeds." });
});

app.listen(PORT, () => console.log(`USL API running on port ${PORT}`));
