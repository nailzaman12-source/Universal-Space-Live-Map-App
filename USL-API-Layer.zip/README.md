# Universal Space Live — API Layer

Initial backend/API layer for USL.

Endpoints:
- GET /
- GET /api/health
- GET /api/earth
- GET /api/space
- GET /api/weather
- GET /api/satellites
- GET /api/disasters

Run:
npm install
npm start

This version provides demo endpoints only. Public data providers and a database will be connected in the next stage.
