// routes/payment.js
const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { authMiddleware } = require('../middleware/auth');
const Payment = require('../models/Payment');
const User = require('../models/User');

// Create payment intent
router.post('/create-payment-intent', authMiddleware, async (req, res) => {
  try {
    const { amount, planType, description } = req.body;

    // Amount in cents
    const amountInCents = Math.round(amount * 100);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountInCents,
      currency: 'usd',
      metadata: {
        userId: req.userId,
        planType: planType,
        description: description
      }
    });

    res.json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Confirm payment
router.post('/confirm-payment', authMiddleware, async (req, res) => {
  try {
    const { paymentIntentId, planType, amount } = req.body;

    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

    if (paymentIntent.status === 'succeeded') {
      // Save payment to database
      const payment = new Payment({
        userId: req.userId,
        paymentIntentId: paymentIntentId,
        amount: amount,
        currency: 'USD',
        planType: planType,
        status: 'completed',
        paymentMethod: 'stripe',
        transactionDate: new Date()
      });

      await payment.save();

      // Update user plan
      const user = await User.findById(req.userId);
      user.subscriptionPlan = planType;
      user.subscriptionExpiry = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
      await user.save();

      res.json({
        success: true,
        message: 'Payment successful!',
        payment: payment
      });
    } else {
      res.status(400).json({ error: 'Payment not confirmed' });
    }

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get payment history
router.get('/history', authMiddleware, async (req, res) => {
  try {
    const payments = await Payment.find({ userId: req.userId })
      .sort({ transactionDate: -1 });

    res.json({ payments });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get payment receipt
router.get('/receipt/:paymentId', authMiddleware, async (req, res) => {
  try {
    const payment = await Payment.findById(req.params.paymentId);

    if (payment.userId.toString() !== req.userId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    res.json({ payment });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get subscription status
router.get('/subscription', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    res.json({
      plan: user.subscriptionPlan || 'free',
      expiryDate: user.subscriptionExpiry,
      isActive: user.subscriptionExpiry > new Date(),
      createdAt: user.createdAt
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
