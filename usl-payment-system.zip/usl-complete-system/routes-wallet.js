// routes/wallet.js
const express = require('express');
const router = express.Router();
const Wallet = require('../models/Wallet');
const { authMiddleware } = require('../middleware/auth');

// Get wallet balance
router.get('/balance', authMiddleware, async (req, res) => {
  try {
    let wallet = await Wallet.findOne({ userId: req.userId });

    if (!wallet) {
      wallet = new Wallet({ userId: req.userId, balance: 0 });
      await wallet.save();
    }

    res.json({
      balance: wallet.balance,
      currency: wallet.currency,
      transactions: wallet.transactions.slice(-10)
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Add credits to wallet
router.post('/add-credits', authMiddleware, async (req, res) => {
  try {
    const { amount, description } = req.body;

    let wallet = await Wallet.findOne({ userId: req.userId });

    if (!wallet) {
      wallet = new Wallet({ userId: req.userId });
    }

    wallet.balance += amount;
    wallet.transactions.push({
      type: 'credit',
      amount: amount,
      description: description || 'Credits added',
      date: new Date()
    });

    await wallet.save();

    res.json({
      message: 'Credits added',
      newBalance: wallet.balance
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Use credits
router.post('/use-credits', authMiddleware, async (req, res) => {
  try {
    const { amount, description } = req.body;

    const wallet = await Wallet.findOne({ userId: req.userId });

    if (!wallet || wallet.balance < amount) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }

    wallet.balance -= amount;
    wallet.transactions.push({
      type: 'debit',
      amount: amount,
      description: description || 'Credits used',
      date: new Date()
    });

    await wallet.save();

    res.json({
      message: 'Credits used',
      newBalance: wallet.balance
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get transaction history
router.get('/transactions', authMiddleware, async (req, res) => {
  try {
    const wallet = await Wallet.findOne({ userId: req.userId });

    if (!wallet) {
      return res.json({ transactions: [] });
    }

    res.json({
      transactions: wallet.transactions.reverse()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
