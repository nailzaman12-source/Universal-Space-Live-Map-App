// pages/Pricing.jsx
import { useState } from 'react';
import { loadStripe } from '@stripe/js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { useAuth } from '../hooks/useAuth';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const PLANS = [
  {
    name: 'Free',
    price: 0,
    type: 'free',
    features: [
      'Basic space data',
      'APOD access',
      'Weather tracking',
      '5 searches/day'
    ]
  },
  {
    name: 'Pro',
    price: 9.99,
    type: 'pro',
    features: [
      'All free features',
      'Unlimited searches',
      'Advanced analytics',
      'API access',
      'Priority support'
    ]
  },
  {
    name: 'Premium',
    price: 29.99,
    type: 'premium',
    features: [
      'All pro features',
      'Custom integrations',
      'Dedicated support',
      'Early access to features',
      'Bulk API requests'
    ]
  }
];

function PaymentForm({ plan, onSuccess, onCancel }) {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const token = localStorage.getItem('token');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Create payment intent
      const intentRes = await fetch(
        `${import.meta.env.VITE_API_URL}/payment/create-payment-intent`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            amount: plan.price,
            planType: plan.type,
            description: `${plan.name} Plan - Monthly Subscription`
          })
        }
      );

      const { clientSecret } = await intentRes.json();

      // Confirm payment
      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
          billing_details: {}
        }
      });

      if (result.paymentIntent.status === 'succeeded') {
        // Confirm payment on backend
        const confirmRes = await fetch(
          `${import.meta.env.VITE_API_URL}/payment/confirm-payment`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
              paymentIntentId: result.paymentIntent.id,
              planType: plan.type,
              amount: plan.price
            })
          }
        );

        const data = await confirmRes.json();

        if (confirmRes.ok) {
          onSuccess(data);
        } else {
          setError(data.error || 'Payment confirmation failed');
        }
      } else {
        setError('Payment failed. Please try again.');
      }
    } catch (err) {
      setError('Error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}

      <div className="border rounded-lg p-4">
        <label className="block text-gray-700 font-bold mb-2">
          Card Details
        </label>
        <CardElement 
          options={{
            style: {
              base: {
                fontSize: '16px',
                color: '#424770',
              },
              invalid: {
                color: '#9e2146',
              },
            },
          }}
        />
      </div>

      <div className="flex gap-4">
        <button
          type="submit"
          disabled={!stripe || loading}
          className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition disabled:opacity-50 font-bold"
        >
          {loading ? 'Processing...' : `Pay $${plan.price}`}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-400 transition font-bold"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}

export default function Pricing() {
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const { user } = useAuth();

  if (paymentSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
        <div className="bg-white rounded-lg shadow-xl p-8 text-center max-w-md">
          <div className="text-5xl mb-4">✅</div>
          <h2 className="text-2xl font-bold text-green-600 mb-2">
            Payment Successful!
          </h2>
          <p className="text-gray-600">
            Your subscription has been activated. Welcome!
          </p>
          <button
            onClick={() => window.location.href = '/dashboard'}
            className="mt-6 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-purple-900 p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-white text-center mb-12">
          Choose Your Plan
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {PLANS.map((plan) => (
            <div
              key={plan.type}
              className={`rounded-lg shadow-lg p-8 transition transform hover:scale-105 ${
                plan.type === 'premium'
                  ? 'bg-yellow-50 border-4 border-yellow-400'
                  : 'bg-white'
              }`}
            >
              {plan.type === 'premium' && (
                <div className="bg-yellow-400 text-yellow-900 text-center py-2 rounded mb-4 font-bold">
                  Most Popular
                </div>
              )}

              <h2 className="text-2xl font-bold mb-2">{plan.name}</h2>
              <p className="text-4xl font-bold text-blue-600 mb-6">
                ${plan.price}
                {plan.price > 0 && <span className="text-lg text-gray-600">/month</span>}
              </p>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center">
                    <span className="text-green-500 mr-3">✓</span>
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              {plan.price > 0 ? (
                <button
                  onClick={() => setSelectedPlan(plan)}
                  className={`w-full py-3 rounded-lg font-bold transition ${
                    plan.type === 'premium'
                      ? 'bg-yellow-400 text-yellow-900 hover:bg-yellow-500'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  Choose Plan
                </button>
              ) : (
                <button
                  disabled
                  className="w-full py-3 rounded-lg font-bold bg-gray-300 text-gray-600 cursor-not-allowed"
                >
                  Your Current Plan
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Payment Modal */}
        {selectedPlan && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
              <h3 className="text-2xl font-bold mb-6">
                Complete Payment
              </h3>

              <div className="bg-blue-50 p-4 rounded mb-6">
                <p className="text-gray-700">
                  <strong>Plan:</strong> {selectedPlan.name}
                </p>
                <p className="text-2xl font-bold text-blue-600 mt-2">
                  ${selectedPlan.price}
                </p>
              </div>

              <Elements stripe={stripePromise}>
                <PaymentForm
                  plan={selectedPlan}
                  onSuccess={() => {
                    setPaymentSuccess(true);
                    setSelectedPlan(null);
                  }}
                  onCancel={() => setSelectedPlan(null)}
                />
              </Elements>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
