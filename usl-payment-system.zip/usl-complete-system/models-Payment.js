// models/Payment.js
const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  amount: {
    type: Number,
    required: true
  },
  
  currency: {
    type: String,
    default: 'USD'
  },
  
  planType: {
    type: String,
    enum: ['free', 'pro', 'premium'],
    default: 'free'
  },
  
  paymentMethod: {
    type: String,
    enum: ['stripe', 'paypal', 'jazzcash', 'easypaisa', 'bank_transfer'],
    required: true
  },
  
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'refunded'],
    default: 'pending'
  },
  
  transactionId: String,
  paymentIntentId: String,
  
  description: String,
  
  invoiceNumber: String,
  
  billingDetails: {
    name: String,
    email: String,
    phone: String,
    address: String,
    city: String,
    country: String,
    postalCode: String
  },
  
  transactionDate: {
    type: Date,
    default: Date.now
  },
  
  refundDate: Date,
  refundReason: String,
  
  notes: String,
  
  createdAt: {
    type: Date,
    default: Date.now
  },
  
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Auto-generate invoice number
paymentSchema.pre('save', async function(next) {
  if (!this.invoiceNumber && this.status === 'completed') {
    const count = await mongoose.model('Payment').countDocuments();
    this.invoiceNumber = `INV-${Date.now()}-${count + 1}`;
  }
  next();
});

module.exports = mongoose.model('Payment', paymentSchema);
