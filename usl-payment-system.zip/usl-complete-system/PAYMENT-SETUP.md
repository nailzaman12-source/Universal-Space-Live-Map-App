# 💳 Universal Space Live - Payment System Setup

## Complete Guide for Payment Integration

---

## 🎯 What's Included

✅ Stripe payment integration
✅ Account management system
✅ Wallet & credits system
✅ Email verification
✅ Password reset system
✅ Invoice generation
✅ Payment history
✅ Subscription plans

---

## 📋 Installation Steps

### Step 1: Install Dependencies

```bash
npm install stripe @stripe/react-stripe-js @stripe/js
npm install jsonwebtoken bcryptjs cookie-parser
npm install nodemailer pdfkit
```

### Step 2: Environment Variables

Add to `.env`:

```env
# Stripe
STRIPE_PUBLIC_KEY=pk_test_xxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxx

# Payment Settings
PAYMENT_CURRENCY=USD

# Email
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password

# Frontend URL
FRONTEND_URL=http://localhost:3000
FRONTEND_URL_PROD=https://noor-portfolio.vercel.app
```

### Step 3: Copy Files

**Backend Files:**
- `models-Payment.js` → `models/Payment.js`
- `models-Wallet.js` → `models/Wallet.js`
- `routes-payment.js` → `routes/payment.js`
- `routes-wallet.js` → `routes/wallet.js`

**Frontend Files:**
- `pages-Pricing.jsx` → `pages/Pricing.jsx`
- `pages-AccountSettings.jsx` → `pages/AccountSettings.jsx`
- `pages-PaymentHistory.jsx` → `pages/PaymentHistory.jsx`

### Step 4: Update server.js

```javascript
const paymentRoutes = require('./routes/payment');
const walletRoutes = require('./routes/wallet');

app.use('/api/payment', paymentRoutes);
app.use('/api/wallet', walletRoutes);
```

### Step 5: Update App.jsx

```javascript
import Pricing from './pages/Pricing';
import AccountSettings from './pages/AccountSettings';
import PaymentHistory from './pages/PaymentHistory';
import { ProtectedRoute } from './components/ProtectedRoute';

<Route path="/pricing" element={<Pricing />} />
<Route path="/settings" element={<ProtectedRoute><AccountSettings /></ProtectedRoute>} />
<Route path="/payments" element={<ProtectedRoute><PaymentHistory /></ProtectedRoute>} />
```

---

## 🔐 Getting Stripe Keys

1. Go to https://stripe.com
2. Create account
3. Go to Dashboard → API keys
4. Copy:
   - Publishable key → `VITE_STRIPE_PUBLIC_KEY`
   - Secret key → `STRIPE_SECRET_KEY`

---

## 📧 Gmail App Password Setup

1. Go to myaccount.google.com
2. Security → Enable 2-Factor Authentication
3. App passwords
4. Generate password for "Mail"
5. Copy and paste in `.env` as `EMAIL_PASSWORD`

---

## 🧪 Test Stripe Cards

```
Visa:        4242 4242 4242 4242
Mastercard:  5555 5555 5555 4444
Amex:        3782 822463 10005

Expiry: Any future date (12/25)
CVC: Any 3 digits (123)
```

---

## 📊 Database Models

### Payment Model

```javascript
{
  userId: ObjectId,
  amount: Number,
  planType: 'free' | 'pro' | 'premium',
  status: 'pending' | 'completed' | 'failed' | 'refunded',
  transactionDate: Date,
  invoiceNumber: String
}
```

### Wallet Model

```javascript
{
  userId: ObjectId,
  balance: Number,
  transactions: [{
    type: 'credit' | 'debit' | 'refund',
    amount: Number,
    date: Date
  }]
}
```

---

## 🔌 API Endpoints

### Payment Routes

```
POST   /api/payment/create-payment-intent
POST   /api/payment/confirm-payment
GET    /api/payment/history
GET    /api/payment/receipt/:paymentId
GET    /api/payment/subscription
```

### Wallet Routes

```
GET    /api/wallet/balance
POST   /api/wallet/add-credits
POST   /api/wallet/use-credits
GET    /api/wallet/transactions
```

---

## 💻 Frontend Integration

### Pricing Page

```javascript
// Navigate to /pricing
// Choose plan
// Pay with Stripe
// Get subscription
```

### Account Settings

```javascript
// Navigate to /settings
// Update profile
// Change password
// Delete account
```

### Payment History

```javascript
// Navigate to /payments
// View all payments
// Download invoices
```

---

## ✅ Subscription Plans

### Free
- $0/month
- Basic features
- 5 searches/day

### Pro
- $9.99/month
- Unlimited searches
- API access
- Priority support

### Premium
- $29.99/month
- All pro features
- Custom integrations
- Dedicated support

---

## 🧪 Testing Checklist

- [ ] Stripe keys configured
- [ ] Email credentials setup
- [ ] Database connected
- [ ] Routes registered
- [ ] Frontend pages created
- [ ] Payment flow works
- [ ] Email verification works
- [ ] Password reset works
- [ ] Invoice generation works
- [ ] Payment history displays

---

## 🚀 Deployment

### Vercel (Frontend)

```bash
npm run build
# Drag dist/ to Vercel
```

### Render (Backend)

1. Push to GitHub
2. Connect to Render
3. Add environment variables
4. Deploy

### Environment Variables (Production)

```env
STRIPE_SECRET_KEY=sk_live_xxxx
FRONTEND_URL=https://your-domain.com
MONGODB_URI=your-production-db
```

---

## 📞 Troubleshooting

### Stripe Payment Fails

```
✅ Check API keys
✅ Verify test card
✅ Check CORS settings
✅ Review backend logs
```

### Email Not Sending

```
✅ Gmail app password correct
✅ 2FA enabled
✅ Less secure apps disabled
✅ Check SMTP settings
```

### Database Connection

```
✅ MongoDB Atlas running
✅ IP whitelisted
✅ Connection string correct
✅ Network access enabled
```

---

## 📚 Resources

- [Stripe Documentation](https://stripe.com/docs)
- [Stripe React Guide](https://stripe.com/docs/stripe-js/react)
- [Nodemailer Guide](https://nodemailer.com/)
- [MongoDB Documentation](https://docs.mongodb.com/)

---

## 🎉 You're All Set!

Your payment system is ready to use!

**Features Enabled:**
✅ Stripe payments
✅ Subscription management
✅ User accounts
✅ Email verification
✅ Password reset
✅ Wallet system
✅ Invoice generation
✅ Payment history

**Next Steps:**
1. Deploy to production
2. Test with real cards (after Stripe approval)
3. Add more payment methods (optional)
4. Monitor payments and receipts

---

**Built for Universal Space Live - Professional Payment Solutions! 💳🚀**
