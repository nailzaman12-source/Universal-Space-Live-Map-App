# 🚀 Quick Implementation Guide

## Complete Checklist to Add Payment System to USL

---

## ✅ Step-by-Step Implementation

### Phase 1: Setup (Day 1-2)

#### Backend Setup

```bash
# 1. Install packages
npm install stripe jsonwebtoken bcryptjs nodemailer pdfkit

# 2. Copy model files
cp models-Payment.js models/Payment.js
cp models-Wallet.js models/Wallet.js

# 3. Copy route files
cp routes-payment.js routes/payment.js
cp routes-wallet.js routes/wallet.js

# 4. Update server.js
# Add payment & wallet routes
app.use('/api/payment', require('./routes/payment'));
app.use('/api/wallet', require('./routes/wallet'));

# 5. Setup .env
# Add STRIPE_PUBLIC_KEY, STRIPE_SECRET_KEY, EMAIL settings
```

#### Frontend Setup

```bash
# 1. Install Stripe packages
npm install @stripe/react-stripe-js @stripe/js

# 2. Copy page files
cp pages-Pricing.jsx pages/Pricing.jsx
cp pages-AccountSettings.jsx pages/AccountSettings.jsx
cp pages-PaymentHistory.jsx pages/PaymentHistory.jsx

# 3. Update App.jsx routes
# Add /pricing, /settings, /payments routes

# 4. Add env variable
# VITE_STRIPE_PUBLIC_KEY=pk_test_xxxx
```

---

### Phase 2: Configuration (Day 3)

#### Get Stripe API Keys

1. Visit https://stripe.com
2. Create account
3. Dashboard → API keys
4. Copy Publishable & Secret keys
5. Add to .env files

#### Get Gmail App Password

1. Google Account → Security
2. Enable 2-Factor Authentication
3. App passwords → Mail
4. Generate and copy
5. Add to .env as EMAIL_PASSWORD

#### Update Environment Files

**Backend .env:**
```env
STRIPE_SECRET_KEY=sk_test_xxx
EMAIL_USER=your@gmail.com
EMAIL_PASSWORD=xxxx_xxxx_xxxx_xxxx
FRONTEND_URL=http://localhost:3000
MONGODB_URI=your_mongo_uri
```

**Frontend .env.local:**
```env
VITE_STRIPE_PUBLIC_KEY=pk_test_xxx
VITE_API_URL=http://localhost:5000/api
```

---

### Phase 3: Testing (Day 4-5)

#### Test Stripe Integration

```bash
# Start backend
npm run dev

# Test payment endpoint
curl -X POST http://localhost:5000/api/payment/create-payment-intent \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "amount": 9.99,
    "planType": "pro",
    "description": "Pro Plan"
  }'
```

#### Test Pricing Page

1. Navigate to /pricing
2. See 3 plans (Free, Pro, Premium)
3. Click "Choose Plan" for Pro
4. Enter test card: 4242 4242 4242 4242
5. Fill random details
6. Submit
7. Should see success page

#### Test Account Settings

1. Navigate to /settings
2. Update profile
3. Change password
4. Should see confirmations

#### Test Payment History

1. Navigate to /payments
2. Should see payment entries
3. Download invoices
4. Verify PDF generation

---

## 📊 File Structure After Implementation

```
backend/
├── models/
│   ├── User.js
│   ├── Payment.js (NEW)
│   └── Wallet.js (NEW)
├── routes/
│   ├── auth.js
│   ├── payment.js (NEW)
│   ├── wallet.js (NEW)
│   └── user.js
├── server.js (UPDATED)
└── .env (UPDATED)

frontend/
├── pages/
│   ├── Dashboard.jsx
│   ├── Pricing.jsx (NEW)
│   ├── AccountSettings.jsx (NEW)
│   ├── PaymentHistory.jsx (NEW)
│   └── ...
├── App.jsx (UPDATED)
└── .env.local (UPDATED)
```

---

## 🧪 Testing Credentials

### Test Credit Cards

```
Visa:        4242 4242 4242 4242
Mastercard:  5555 5555 5555 4444
Amex:        3782 822463 10005

CVC: Any 3 digits
Expiry: Any future date
```

### Test User Credentials

```
Email: test@example.com
Password: Password123!
Plan: Pro
Amount: $9.99
```

---

## ✅ Verification Checklist

After implementation, verify:

- [ ] Backend compiles without errors
- [ ] Frontend builds successfully
- [ ] Pricing page displays all plans
- [ ] Can create Stripe payment intent
- [ ] Test payment succeeds
- [ ] Payment saved to database
- [ ] Email verification works
- [ ] Password reset email sends
- [ ] Account settings updateable
- [ ] Payment history displays
- [ ] Invoice PDF downloads
- [ ] Wallet balance updates
- [ ] All routes protected

---

## 🔧 Common Issues & Fixes

### Stripe Key Not Working

```
✅ Verify key format (pk_test_ or sk_test_)
✅ Check STRIPE_SECRET_KEY in server
✅ Check VITE_STRIPE_PUBLIC_KEY in frontend
✅ No spaces in .env
```

### Email Not Sending

```
✅ Gmail 2FA enabled
✅ App password correct (16 chars)
✅ Less secure apps disabled
✅ EMAIL_USER matches Gmail
```

### Database Error

```
✅ MongoDB running locally or Atlas
✅ Connection string correct
✅ IP whitelisted (Atlas)
✅ Network access enabled
```

### CORS Error

```
✅ Backend CORS enabled
✅ Frontend URL in CORS_ORIGIN
✅ API URL correct in .env
✅ Reload page after changes
```

---

## 🚀 Deployment Checklist

Before going live:

- [ ] All env variables set
- [ ] Stripe keys are production keys
- [ ] Database is production database
- [ ] Email domain verified
- [ ] HTTPS enabled
- [ ] Error logging setup
- [ ] Rate limiting enabled
- [ ] All payments tested
- [ ] Invoice generation verified
- [ ] Backup strategy planned

---

## 📈 Next Features (Optional)

After basic payment working:

- [ ] Multiple payment methods (PayPal, JazzCash)
- [ ] Refund system
- [ ] Subscription renewal
- [ ] Usage tracking
- [ ] Analytics dashboard
- [ ] Tax calculation
- [ ] Coupon codes
- [ ] Volume discounts

---

## 💬 Support

If stuck:

1. Check logs: `npm run dev`
2. Verify .env variables
3. Test with curl/Postman
4. Check Stripe dashboard
5. Review documentation

---

## 🎉 Success Indicators

When complete, you should see:

✅ Pricing page with 3 plans
✅ Functional checkout
✅ Payment confirmations
✅ Account management
✅ Payment history
✅ Invoice generation
✅ Subscription status

---

**Ready? Start with Phase 1 Today! 🚀**

**Questions? Check PAYMENT-SETUP.md for detailed instructions!**
