// pages/PaymentHistory.jsx
import { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Download } from 'lucide-react';

export default function PaymentHistory() {
  const { token } = useAuth();
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const response = await fetch(
          `${import.meta.env.VITE_API_URL}/payment/history`,
          {
            headers: { 'Authorization': `Bearer ${token}` }
          }
        );

        const data = await response.json();
        setPayments(data.payments);
      } catch (error) {
        console.error('Error fetching payments:', error);
      } finally {
        setLoading(false);
      }
    };

    if (token) fetchPayments();
  }, [token]);

  const downloadInvoice = async (paymentId) => {
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_URL}/payment/invoice/${paymentId}`,
        {
          headers: { 'Authorization': `Bearer ${token}` }
        }
      );

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'invoice.pdf';
      a.click();
    } catch (error) {
      console.error('Error downloading invoice:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
        <div className="text-white text-2xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-purple-900 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-8">Payment History</h1>

        {payments.length === 0 ? (
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <p className="text-gray-600 text-lg">No payments yet</p>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-6 py-3 text-left font-bold">Date</th>
                  <th className="px-6 py-3 text-left font-bold">Plan</th>
                  <th className="px-6 py-3 text-left font-bold">Amount</th>
                  <th className="px-6 py-3 text-left font-bold">Status</th>
                  <th className="px-6 py-3 text-left font-bold">Invoice</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((payment) => (
                  <tr key={payment._id} className="border-t hover:bg-gray-50">
                    <td className="px-6 py-4">
                      {new Date(payment.transactionDate).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 font-bold capitalize">
                      {payment.planType}
                    </td>
                    <td className="px-6 py-4">
                      ${payment.amount.toFixed(2)}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                        payment.status === 'completed'
                          ? 'bg-green-100 text-green-800'
                          : payment.status === 'failed'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {payment.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => downloadInvoice(payment._id)}
                        className="flex items-center gap-2 text-blue-600 hover:text-blue-800"
                      >
                        <Download size={18} />
                        Download
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
