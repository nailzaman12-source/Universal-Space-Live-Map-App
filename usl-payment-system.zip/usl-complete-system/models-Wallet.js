// models/Wallet.js
const mongoose = require('mongoose');

const walletSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  
  balance: {
    type: Number,
    default: 0
  },
  
  currency: {
    type: String,
    default: 'USD'
  },
  
  transactions: [{
    type: {
      type: String,
      enum: ['credit', 'debit', 'refund'],
      required: true
    },
    amount: Number,
    description: String,
    paymentId: mongoose.Schema.Types.ObjectId,
    date: {
      type: Date,
      default: Date.now
    }
  }],
  
  createdAt: {
    type: Date,
    default: Date.now
  },
  
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Wallet', walletSchema);
