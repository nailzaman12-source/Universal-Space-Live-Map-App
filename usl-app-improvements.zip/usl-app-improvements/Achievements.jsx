// components/AchievementCard.jsx
export default function AchievementCard({ achievement, unlocked }) {
  return (
    <div className={`border-2 rounded-lg p-4 text-center transition transform ${
      unlocked
        ? 'border-yellow-400 bg-yellow-50 scale-105 shadow-lg'
        : 'border-gray-300 bg-gray-100 opacity-60'
    }`}>
      <div className="text-5xl mb-2">{achievement.icon}</div>
      <h3 className="font-bold text-lg mb-1">{achievement.name}</h3>
      <p className="text-sm text-gray-600 mb-2">{achievement.description}</p>
      {unlocked && (
        <p className="text-yellow-600 font-bold text-sm">✓ Unlocked!</p>
      )}
      <p className="text-xs text-gray-500 mt-2">+{achievement.points} XP</p>
    </div>
  );
}

// utils/achievements.js
export const ACHIEVEMENTS = [
  {
    id: 'first_login',
    name: 'Welcome Astronaut',
    description: 'Complete your first login',
    icon: '🚀',
    points: 10,
    condition: (user) => user.loginCount >= 1
  },
  {
    id: 'first_lesson',
    name: 'Learning Started',
    description: 'Complete your first lesson',
    icon: '📚',
    points: 50,
    condition: (user) => user.lessonsCompleted >= 1
  },
  {
    id: 'space_explorer',
    name: 'Space Explorer',
    description: 'View 10 NASA images',
    icon: '🌌',
    points: 100,
    condition: (user) => user.nasaViewCount >= 10
  },
  {
    id: 'weather_watcher',
    name: 'Weather Watcher',
    description: 'Check weather 5 times',
    icon: '🌤️',
    points: 50,
    condition: (user) => user.weatherCheckCount >= 5
  },
  {
    id: 'earthquake_expert',
    name: 'Earthquake Expert',
    description: 'Track 10 earthquakes',
    icon: '📊',
    points: 100,
    condition: (user) => user.earthquakeTrackCount >= 10
  },
  {
    id: 'dedicated_learner',
    name: 'Dedicated Learner',
    description: '7-day learning streak',
    icon: '🔥',
    points: 250,
    condition: (user) => user.learningStreak >= 7
  },
  {
    id: 'night_owl',
    name: 'Night Owl',
    description: 'Learn after 9 PM',
    icon: '🌙',
    points: 75,
    condition: (user) => user.nightSessionCount >= 5
  },
  {
    id: 'master_learner',
    name: 'Master Learner',
    description: 'Complete 50 lessons',
    icon: '🎓',
    points: 500,
    condition: (user) => user.lessonsCompleted >= 50
  }
];

// pages/Achievements.jsx
import { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import AchievementCard from '../components/AchievementCard';
import { ACHIEVEMENTS } from '../utils/achievements';

export default function Achievements() {
  const { user, token } = useAuth();
  const [achievements, setAchievements] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    unlocked: 0,
    locked: 0,
    totalPoints: 0
  });

  useEffect(() => {
    const fetchAchievements = async () => {
      try {
        const response = await fetch(
          `${import.meta.env.VITE_API_URL}/user/achievements`,
          {
            headers: { 'Authorization': `Bearer ${token}` }
          }
        );

        const data = await response.json();
        setAchievements(data.achievements || []);

        const unlocked = data.achievements?.length || 0;
        const locked = ACHIEVEMENTS.length - unlocked;
        const totalPoints = data.achievements?.reduce((sum, a) => sum + a.points, 0) || 0;

        setStats({
          total: ACHIEVEMENTS.length,
          unlocked,
          locked,
          totalPoints
        });
      } catch (error) {
        console.error('Error fetching achievements:', error);
      }
    };

    if (token) fetchAchievements();
  }, [token]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-purple-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-white mb-2">🏆 Achievements</h1>
        <p className="text-blue-200 mb-8">Earn badges as you learn and explore</p>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-4 text-white text-center">
            <div className="text-3xl font-bold">{stats.total}</div>
            <p className="text-blue-200">Total</p>
          </div>
          <div className="bg-yellow-400 bg-opacity-20 backdrop-blur-lg rounded-lg p-4 text-white text-center">
            <div className="text-3xl font-bold">{stats.unlocked}</div>
            <p className="text-yellow-200">Unlocked</p>
          </div>
          <div className="bg-gray-400 bg-opacity-20 backdrop-blur-lg rounded-lg p-4 text-white text-center">
            <div className="text-3xl font-bold">{stats.locked}</div>
            <p className="text-gray-200">Locked</p>
          </div>
          <div className="bg-green-400 bg-opacity-20 backdrop-blur-lg rounded-lg p-4 text-white text-center">
            <div className="text-3xl font-bold">{stats.totalPoints}</div>
            <p className="text-green-200">Total XP</p>
          </div>
        </div>

        {/* Achievements Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {ACHIEVEMENTS.map((achievement) => {
            const isUnlocked = achievements.some(a => a.id === achievement.id);
            return (
              <AchievementCard
                key={achievement.id}
                achievement={achievement}
                unlocked={isUnlocked}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
