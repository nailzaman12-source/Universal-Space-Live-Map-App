// components/Navbar.jsx
import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Menu, X, LogOut, Settings, Home, Zap, Trophy, ShoppingCart } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const menuItems = [
    { name: 'Home', icon: Home, href: '/', show: true },
    { name: 'Dashboard', icon: Zap, href: '/dashboard', show: !!user },
    { name: 'Achievements', icon: Trophy, href: '/achievements', show: !!user },
    { name: 'Pricing', icon: ShoppingCart, href: '/pricing', show: true },
    { name: 'Settings', icon: Settings, href: '/settings', show: !!user },
  ];

  return (
    <nav className="bg-gradient-to-r from-blue-900 to-purple-900 shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-2xl">🌌</span>
            <span className="text-white font-bold text-lg hidden sm:inline">USL</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-1">
            {menuItems.filter(item => item.show).map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="text-white hover:bg-white hover:bg-opacity-20 px-3 py-2 rounded-lg transition flex items-center space-x-1"
              >
                <item.icon size={18} />
                <span>{item.name}</span>
              </Link>
            ))}
          </div>

          {/* Right Side */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <>
                <div className="text-white">
                  <p className="text-sm">{user.name}</p>
                </div>
                <button
                  onClick={handleLogout}
                  className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition"
                >
                  <LogOut size={18} />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-white hover:text-blue-200 transition">
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition"
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-white p-2"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden bg-blue-800 bg-opacity-95 backdrop-blur-lg border-t border-blue-700">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {menuItems.filter(item => item.show).map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:bg-white hover:bg-opacity-20 block px-3 py-2 rounded-lg transition flex items-center space-x-2"
                >
                  <item.icon size={18} />
                  <span>{item.name}</span>
                </Link>
              ))}

              <div className="border-t border-blue-700 pt-2 mt-2">
                {user ? (
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsOpen(false);
                    }}
                    className="w-full text-left text-red-400 hover:bg-red-500 hover:bg-opacity-20 px-3 py-2 rounded-lg transition flex items-center space-x-2"
                  >
                    <LogOut size={18} />
                    <span>Logout</span>
                  </button>
                ) : (
                  <div className="space-y-2">
                    <Link
                      to="/login"
                      onClick={() => setIsOpen(false)}
                      className="block text-white hover:bg-white hover:bg-opacity-20 px-3 py-2 rounded-lg transition"
                    >
                      Login
                    </Link>
                    <Link
                      to="/signup"
                      onClick={() => setIsOpen(false)}
                      className="block bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg transition text-center"
                    >
                      Sign Up
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
