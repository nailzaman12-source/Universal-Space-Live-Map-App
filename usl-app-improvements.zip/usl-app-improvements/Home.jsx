// pages/Home.jsx
import { useAuth } from '../hooks/useAuth';
import { Rocket, Globe, BookOpen, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-black">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              🌌 Explore Earth.<br />Discover Space.<br />Learn with AI.
            </h1>
            <p className="text-xl text-blue-200 mb-8">
              Universal Space Live brings real-time astronomy and space science to your fingertips. 
              Learn, explore, and earn achievements as you discover the universe.
            </p>
            
            <div className="flex gap-4 flex-wrap">
              {user ? (
                <>
                  <Link
                    to="/dashboard"
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-bold transition"
                  >
                    Go to Dashboard
                  </Link>
                  <Link
                    to="/achievements"
                    className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-lg font-bold transition"
                  >
                    View Achievements
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    to="/signup"
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-bold transition"
                  >
                    Get Started Free
                  </Link>
                  <Link
                    to="/login"
                    className="bg-gray-700 hover:bg-gray-800 text-white px-8 py-3 rounded-lg font-bold transition"
                  >
                    Sign In
                  </Link>
                </>
              )}
            </div>
          </div>

          <div className="flex justify-center">
            <div className="text-9xl animate-float">🚀</div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-black bg-opacity-40 py-20 mt-20">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-white text-center mb-16">
            Amazing Features
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Feature 1 */}
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-lg p-6 border border-white border-opacity-20">
              <Rocket className="text-blue-400 mb-4" size={40} />
              <h3 className="text-xl font-bold text-white mb-2">Real-time Data</h3>
              <p className="text-blue-200">
                Access live NASA data, earthquake tracking, and ISS location updates.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-lg p-6 border border-white border-opacity-20">
              <BookOpen className="text-purple-400 mb-4" size={40} />
              <h3 className="text-xl font-bold text-white mb-2">Learn & Grow</h3>
              <p className="text-blue-200">
                Comprehensive space science courses with interactive lessons and quizzes.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-lg p-6 border border-white border-opacity-20">
              <Zap className="text-yellow-400 mb-4" size={40} />
              <h3 className="text-xl font-bold text-white mb-2">Earn Achievements</h3>
              <p className="text-blue-200">
                Unlock badges and track your progress as you explore the universe.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-lg p-6 border border-white border-opacity-20">
              <Globe className="text-green-400 mb-4" size={40} />
              <h3 className="text-xl font-bold text-white mb-2">Global Access</h3>
              <p className="text-blue-200">
                Available worldwide in 10+ languages with multi-region support.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg p-6 text-white text-center">
            <div className="text-4xl font-bold mb-2">50+</div>
            <p className="text-blue-100">NASA Datasets</p>
          </div>
          <div className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-lg p-6 text-white text-center">
            <div className="text-4xl font-bold mb-2">1000+</div>
            <p className="text-purple-100">Lessons Available</p>
          </div>
          <div className="bg-gradient-to-br from-pink-600 to-pink-800 rounded-lg p-6 text-white text-center">
            <div className="text-4xl font-bold mb-2">100+</div>
            <p className="text-pink-100">Achievement Badges</p>
          </div>
          <div className="bg-gradient-to-br from-green-600 to-green-800 rounded-lg p-6 text-white text-center">
            <div className="text-4xl font-bold mb-2">50M+</div>
            <p className="text-green-100">Users Worldwide</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Explore the Universe?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of learners discovering space and earning achievements.
          </p>
          
          {user ? (
            <Link
              to="/dashboard"
              className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition"
            >
              Go to Dashboard
            </Link>
          ) : (
            <Link
              to="/signup"
              className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition"
            >
              Get Started Free
            </Link>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black bg-opacity-60 py-12 border-t border-white border-opacity-10">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-white font-bold mb-4">🌌 Universal Space Live</h3>
              <p className="text-gray-400 text-sm">
                Making space science accessible to everyone.
              </p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="/" className="hover:text-white">Features</a></li>
                <li><a href="/pricing" className="hover:text-white">Pricing</a></li>
                <li><a href="#" className="hover:text-white">Lessons</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-white">Privacy</a></li>
                <li><a href="#" className="hover:text-white">Terms</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white border-opacity-10 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2026 Universal Space Live. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
