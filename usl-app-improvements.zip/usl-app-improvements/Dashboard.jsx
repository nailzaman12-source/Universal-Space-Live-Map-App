// pages/Dashboard.jsx
import { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Cloud, AlertTriangle, Zap, Satellite } from 'lucide-react';

export default function Dashboard() {
  const { user, token } = useAuth();
  const [data, setData] = useState({
    apod: null,
    weather: null,
    earthquakes: null,
    issLocation: null
  });
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    lessonsCompleted: 0,
    xpPoints: 0,
    streak: 0,
    achievements: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      const API_URL = import.meta.env.VITE_API_URL;

      try {
        // Fetch APOD
        const apodRes = await fetch(`${API_URL}/nasa/apod`);
        const apodData = await apodRes.json();

        // Fetch Weather (Default: Karachi)
        const weatherRes = await fetch(`${API_URL}/weather/current/Karachi`);
        const weatherData = await weatherRes.json();

        // Fetch Earthquakes
        const eqRes = await fetch(`${API_URL}/disaster/earthquakes`);
        const eqData = await eqRes.json();

        // Fetch ISS Location
        const issRes = await fetch(`${API_URL}/space-events/iss-location`);
        const issData = await issRes.json();

        setData({
          apod: apodData,
          weather: weatherData,
          earthquakes: eqData,
          issLocation: issData
        });

        // Fetch user stats if authenticated
        if (token) {
          const progressRes = await fetch(`${API_URL}/user/progress`, {
            headers: { 'Authorization': `Bearer ${token}` }
          });
          const progressData = await progressRes.json();
          setStats({
            lessonsCompleted: progressData.totalLessonsCompleted || 0,
            xpPoints: progressData.experiencePoints || 0,
            streak: progressData.learningStreak || 0,
            achievements: progressData.achievements?.length || 0
          });
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    // Refresh every 5 minutes
    const interval = setInterval(fetchData, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [token]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
        <div className="text-white text-2xl">🌌 Loading Dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-purple-900 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            🌌 Welcome back, {user?.name}!
          </h1>
          <p className="text-blue-200">Universal Space Live Dashboard</p>
        </div>

        {/* Stats Grid */}
        {user && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-6 text-white">
              <div className="text-3xl font-bold">{stats.lessonsCompleted}</div>
              <p className="text-blue-200">Lessons Completed</p>
            </div>
            <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-6 text-white">
              <div className="text-3xl font-bold">{stats.xpPoints}</div>
              <p className="text-blue-200">XP Points</p>
            </div>
            <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-6 text-white">
              <div className="text-3xl font-bold">{stats.streak}🔥</div>
              <p className="text-blue-200">Day Streak</p>
            </div>
            <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-6 text-white">
              <div className="text-3xl font-bold">{stats.achievements}</div>
              <p className="text-blue-200">Achievements</p>
            </div>
          </div>
        )}

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* APOD Card */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-4">🌌 Astronomy Picture of the Day</h2>
              {data.apod?.url && (
                <img
                  src={data.apod.url}
                  alt={data.apod.title}
                  className="w-full rounded-lg mb-4 max-h-64 object-cover"
                />
              )}
              <h3 className="font-bold text-lg mb-2">{data.apod?.title}</h3>
              <p className="text-gray-600 text-sm">{data.apod?.explanation?.substring(0, 200)}...</p>
            </div>
          </div>

          {/* Weather Card */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <Cloud className="mr-2" /> Current Weather
            </h2>
            {data.weather && (
              <div className="space-y-4">
                <div>
                  <p className="text-gray-600">Temperature</p>
                  <p className="text-4xl font-bold text-blue-600">
                    {Math.round(data.weather.main?.temp || 0)}°C
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Condition</p>
                  <p className="text-lg font-semibold capitalize">
                    {data.weather.weather?.[0]?.description}
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-600 text-sm">Humidity</p>
                    <p className="text-2xl font-bold">{data.weather.main?.humidity}%</p>
                  </div>
                  <div>
                    <p className="text-gray-600 text-sm">Wind Speed</p>
                    <p className="text-2xl font-bold">{data.weather.wind?.speed} m/s</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Earthquakes Card */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <AlertTriangle className="mr-2 text-red-500" /> Recent Earthquakes
            </h2>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {data.earthquakes?.features?.slice(0, 5).map((eq, idx) => (
                <div key={idx} className="border-l-4 border-red-500 pl-4 py-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold text-lg">Magnitude {eq.properties.mag}</p>
                      <p className="text-gray-600 text-sm">{eq.properties.place}</p>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs font-bold ${
                      eq.properties.mag >= 6 ? 'bg-red-200 text-red-800' :
                      eq.properties.mag >= 4 ? 'bg-yellow-200 text-yellow-800' :
                      'bg-green-200 text-green-800'
                    }`}>
                      {eq.properties.mag >= 6 ? 'High' : eq.properties.mag >= 4 ? 'Medium' : 'Low'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ISS Location Card */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <Satellite className="mr-2" /> ISS Real-time Location
            </h2>
            {data.issLocation && (
              <div className="space-y-4">
                <div className="bg-blue-50 rounded-lg p-4">
                  <p className="text-gray-600 text-sm">Latitude</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {data.issLocation.latitude?.toFixed(4)}°
                  </p>
                </div>
                <div className="bg-blue-50 rounded-lg p-4">
                  <p className="text-gray-600 text-sm">Longitude</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {data.issLocation.longitude?.toFixed(4)}°
                  </p>
                </div>
                <div className="bg-blue-50 rounded-lg p-4">
                  <p className="text-gray-600 text-sm">Altitude</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {Math.round(data.issLocation.altitude)} km
                  </p>
                </div>
                <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition">
                  View on Map
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
